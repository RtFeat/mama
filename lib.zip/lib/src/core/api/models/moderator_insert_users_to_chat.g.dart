// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'moderator_insert_users_to_chat.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

ModeratorInsertUsersToChat _$ModeratorInsertUsersToChatFromJson(
        Map<String, dynamic> json) =>
    ModeratorInsertUsersToChat(
      idGroupChat: json['id_group_chat'] as String?,
      idsUsers: (json['ids_users'] as List<dynamic>?)
          ?.map((e) => e as String)
          .toList(),
    );

Map<String, dynamic> _$ModeratorInsertUsersToChatToJson(
        ModeratorInsertUsersToChat instance) =>
    <String, dynamic>{
      'id_group_chat': instance.idGroupChat,
      'ids_users': instance.idsUsers,
    };
