// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'entity_article_image.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

EntityArticleImage _$EntityArticleImageFromJson(Map<String, dynamic> json) =>
    EntityArticleImage(
      id: json['id'] as String?,
      index: (json['index'] as num?)?.toInt(),
      photoId: json['photo_id'] as String?,
      photoUrl: json['photo_url'] as String?,
    );

Map<String, dynamic> _$EntityArticleImageToJson(EntityArticleImage instance) =>
    <String, dynamic>{
      'id': instance.id,
      'index': instance.index,
      'photo_id': instance.photoId,
      'photo_url': instance.photoUrl,
    };
