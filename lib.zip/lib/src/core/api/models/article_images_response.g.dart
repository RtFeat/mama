// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'article_images_response.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

ArticleImagesResponse _$ArticleImagesResponseFromJson(
        Map<String, dynamic> json) =>
    ArticleImagesResponse(
      images: (json['images'] as List<dynamic>?)
          ?.map((e) => EntityArticleImage.fromJson(e as Map<String, dynamic>))
          .toList(),
    );

Map<String, dynamic> _$ArticleImagesResponseToJson(
        ArticleImagesResponse instance) =>
    <String, dynamic>{
      'images': instance.images,
    };
