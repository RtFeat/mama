// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'doctor_delete_dto.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

DoctorDeleteDto _$DoctorDeleteDtoFromJson(Map<String, dynamic> json) =>
    DoctorDeleteDto(
      id: json['id'] as String?,
    );

Map<String, dynamic> _$DoctorDeleteDtoToJson(DoctorDeleteDto instance) =>
    <String, dynamic>{
      'id': instance.id,
    };
