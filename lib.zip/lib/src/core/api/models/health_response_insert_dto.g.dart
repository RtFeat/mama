// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'health_response_insert_dto.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

HealthResponseInsertDto _$HealthResponseInsertDtoFromJson(
        Map<String, dynamic> json) =>
    HealthResponseInsertDto(
      id: json['id'] as String?,
    );

Map<String, dynamic> _$HealthResponseInsertDtoToJson(
        HealthResponseInsertDto instance) =>
    <String, dynamic>{
      'id': instance.id,
    };
