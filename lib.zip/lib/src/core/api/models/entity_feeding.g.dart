// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'entity_feeding.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

EntityFeeding _$EntityFeedingFromJson(Map<String, dynamic> json) =>
    EntityFeeding(
      allFeeding: (json['all_feeding'] as num?)?.toInt(),
      childId: json['child_id'] as String?,
      id: json['id'] as String?,
      leftFeeding: (json['left_feeding'] as num?)?.toInt(),
      notes: json['notes'] as String?,
      rightFeeding: (json['right_feeding'] as num?)?.toInt(),
      timeToEnd: json['time_to_end'] as String?,
    );

Map<String, dynamic> _$EntityFeedingToJson(EntityFeeding instance) =>
    <String, dynamic>{
      'all_feeding': instance.allFeeding,
      'child_id': instance.childId,
      'id': instance.id,
      'left_feeding': instance.leftFeeding,
      'notes': instance.notes,
      'right_feeding': instance.rightFeeding,
      'time_to_end': instance.timeToEnd,
    };
