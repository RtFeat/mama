// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'entity_single_chat.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

EntitySingleChat _$EntitySingleChatFromJson(Map<String, dynamic> json) =>
    EntitySingleChat(
      createdAt: json['created_at'] as String?,
      id: json['id'] as String?,
      isDeleted: json['is_deleted'] as bool?,
      lastMessage: json['last_message'] == null
          ? null
          : EntityMessage.fromJson(
              json['last_message'] as Map<String, dynamic>),
      lastMessageAt: json['last_message_at'] as String?,
      participant1Id: json['participant1_id'] as String?,
      participant1Unread: json['participant1_unread'] as String?,
      participant2Id: json['participant2_id'] as String?,
      participant2Unread: json['participant2_unread'] as String?,
      participant1: json['participant_1'] == null
          ? null
          : EntityAccount.fromJson(
              json['participant_1'] as Map<String, dynamic>),
      participant2: json['participant_2'] == null
          ? null
          : EntityAccount.fromJson(
              json['participant_2'] as Map<String, dynamic>),
      profession: json['profession'] as String?,
      professionId: json['profession_id'] as String?,
      unreadMessages: (json['unread_messages'] as num?)?.toInt(),
    );

Map<String, dynamic> _$EntitySingleChatToJson(EntitySingleChat instance) =>
    <String, dynamic>{
      'created_at': instance.createdAt,
      'id': instance.id,
      'is_deleted': instance.isDeleted,
      'last_message': instance.lastMessage,
      'last_message_at': instance.lastMessageAt,
      'participant1_id': instance.participant1Id,
      'participant1_unread': instance.participant1Unread,
      'participant2_id': instance.participant2Id,
      'participant2_unread': instance.participant2Unread,
      'participant_1': instance.participant1,
      'participant_2': instance.participant2,
      'profession': instance.profession,
      'profession_id': instance.professionId,
      'unread_messages': instance.unreadMessages,
    };
