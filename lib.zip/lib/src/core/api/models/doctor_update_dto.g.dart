// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'doctor_update_dto.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

DoctorUpdateDto _$DoctorUpdateDtoFromJson(Map<String, dynamic> json) =>
    DoctorUpdateDto(
      email: json['email'] as String?,
      firstName: json['first_name'] as String?,
      gender: json['gender'] as String?,
      info: json['info'] as String?,
      lastName: json['last_name'] as String?,
      profession: json['profession'] as String?,
      secondName: json['second_name'] as String?,
    );

Map<String, dynamic> _$DoctorUpdateDtoToJson(DoctorUpdateDto instance) =>
    <String, dynamic>{
      'email': instance.email,
      'first_name': instance.firstName,
      'gender': instance.gender,
      'info': instance.info,
      'last_name': instance.lastName,
      'profession': instance.profession,
      'second_name': instance.secondName,
    };
