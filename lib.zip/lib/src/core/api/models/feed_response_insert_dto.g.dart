// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'feed_response_insert_dto.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

FeedResponseInsertDto _$FeedResponseInsertDtoFromJson(
        Map<String, dynamic> json) =>
    FeedResponseInsertDto(
      id: json['id'] as String?,
    );

Map<String, dynamic> _$FeedResponseInsertDtoToJson(
        FeedResponseInsertDto instance) =>
    <String, dynamic>{
      'id': instance.id,
    };
