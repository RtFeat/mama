// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'sleepcry_insert_cry_dto.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

SleepcryInsertCryDto _$SleepcryInsertCryDtoFromJson(
        Map<String, dynamic> json) =>
    SleepcryInsertCryDto(
      allCry: json['all_cry'] as String?,
      childId: json['child_id'] as String?,
      notes: json['notes'] as String?,
      timeEnd: json['time_end'] as String?,
      timeToEnd: json['time_to_end'] as String?,
      timeToStart: json['time_to_start'] as String?,
    );

Map<String, dynamic> _$SleepcryInsertCryDtoToJson(
        SleepcryInsertCryDto instance) =>
    <String, dynamic>{
      'all_cry': instance.allCry,
      'child_id': instance.childId,
      'notes': instance.notes,
      'time_end': instance.timeEnd,
      'time_to_end': instance.timeToEnd,
      'time_to_start': instance.timeToStart,
    };
