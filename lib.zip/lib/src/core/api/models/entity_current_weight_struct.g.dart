// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'entity_current_weight_struct.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

EntityCurrentWeightStruct _$EntityCurrentWeightStructFromJson(
        Map<String, dynamic> json) =>
    EntityCurrentWeightStruct(
      time: json['time'] as String?,
      weight: json['weight'] as String?,
    );

Map<String, dynamic> _$EntityCurrentWeightStructToJson(
        EntityCurrentWeightStruct instance) =>
    <String, dynamic>{
      'time': instance.time,
      'weight': instance.weight,
    };
