// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'moderator_resp_promocode.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

ModeratorRespPromocode _$ModeratorRespPromocodeFromJson(
        Map<String, dynamic> json) =>
    ModeratorRespPromocode(
      list: (json['list'] as List<dynamic>?)
          ?.map((e) => EntityPromocode.fromJson(e as Map<String, dynamic>))
          .toList(),
    );

Map<String, dynamic> _$ModeratorRespPromocodeToJson(
        ModeratorRespPromocode instance) =>
    <String, dynamic>{
      'list': instance.list,
    };
