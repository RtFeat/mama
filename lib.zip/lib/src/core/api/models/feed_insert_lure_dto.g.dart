// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'feed_insert_lure_dto.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

FeedInsertLureDto _$FeedInsertLureDtoFromJson(Map<String, dynamic> json) =>
    FeedInsertLureDto(
      lure: (json['lure'] as List<dynamic>?)
          ?.map((e) => EntityInsertLure.fromJson(e as Map<String, dynamic>))
          .toList(),
    );

Map<String, dynamic> _$FeedInsertLureDtoToJson(FeedInsertLureDto instance) =>
    <String, dynamic>{
      'lure': instance.lure,
    };
