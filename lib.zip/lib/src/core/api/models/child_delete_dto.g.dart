// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'child_delete_dto.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

ChildDeleteDto _$ChildDeleteDtoFromJson(Map<String, dynamic> json) =>
    ChildDeleteDto(
      childId: json['child_id'] as String,
    );

Map<String, dynamic> _$ChildDeleteDtoToJson(ChildDeleteDto instance) =>
    <String, dynamic>{
      'child_id': instance.childId,
    };
