// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'chat_file_response.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

ChatFileResponse _$ChatFileResponseFromJson(Map<String, dynamic> json) =>
    ChatFileResponse(
      message: json['message'] == null
          ? null
          : EntityMessageResp.fromJson(json['message'] as Map<String, dynamic>),
    );

Map<String, dynamic> _$ChatFileResponseToJson(ChatFileResponse instance) =>
    <String, dynamic>{
      'message': instance.message,
    };
