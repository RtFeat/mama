// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'doctor_doctor_response.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

DoctorDoctorResponse _$DoctorDoctorResponseFromJson(
        Map<String, dynamic> json) =>
    DoctorDoctorResponse(
      doctor: json['doctor'] == null
          ? null
          : EntityDoctorResponse.fromJson(
              json['doctor'] as Map<String, dynamic>),
    );

Map<String, dynamic> _$DoctorDoctorResponseToJson(
        DoctorDoctorResponse instance) =>
    <String, dynamic>{
      'doctor': instance.doctor,
    };
