// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'entity_favorite_article_response.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

EntityFavoriteArticleResponse _$EntityFavoriteArticleResponseFromJson(
        Map<String, dynamic> json) =>
    EntityFavoriteArticleResponse(
      ageCategory: (json['age_category'] as List<dynamic>?)
          ?.map((e) => e as String)
          .toList(),
      articlePhoto: json['article_photo'] as String?,
      author: json['author'] as String?,
      authorAvatar: json['author_avatar'] as String?,
      authorProfession: json['author_profession'] as String?,
      category: json['category'] as String?,
      id: json['id'] as String?,
      title: json['title'] as String?,
    );

Map<String, dynamic> _$EntityFavoriteArticleResponseToJson(
        EntityFavoriteArticleResponse instance) =>
    <String, dynamic>{
      'age_category': instance.ageCategory,
      'article_photo': instance.articlePhoto,
      'author': instance.author,
      'author_avatar': instance.authorAvatar,
      'author_profession': instance.authorProfession,
      'category': instance.category,
      'id': instance.id,
      'title': instance.title,
    };
