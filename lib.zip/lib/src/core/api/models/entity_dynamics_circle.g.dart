// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'entity_dynamics_circle.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

EntityDynamicsCircle _$EntityDynamicsCircleFromJson(
        Map<String, dynamic> json) =>
    EntityDynamicsCircle(
      circleGain: json['circle_gain'] as String?,
      circleToDay: json['circle_to_day'] as String?,
      days: json['days'] as String?,
      timeDuration: json['time_duration'] as String?,
    );

Map<String, dynamic> _$EntityDynamicsCircleToJson(
        EntityDynamicsCircle instance) =>
    <String, dynamic>{
      'circle_gain': instance.circleGain,
      'circle_to_day': instance.circleToDay,
      'days': instance.days,
      'time_duration': instance.timeDuration,
    };
