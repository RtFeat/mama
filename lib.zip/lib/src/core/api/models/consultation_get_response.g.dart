// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'consultation_get_response.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

ConsultationGetResponse _$ConsultationGetResponseFromJson(
        Map<String, dynamic> json) =>
    ConsultationGetResponse(
      consultation: json['consultation'] == null
          ? null
          : EntityConsultationResponse.fromJson(
              json['consultation'] as Map<String, dynamic>),
    );

Map<String, dynamic> _$ConsultationGetResponseToJson(
        ConsultationGetResponse instance) =>
    <String, dynamic>{
      'consultation': instance.consultation,
    };
