// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'entity_get_circle.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

EntityGetCircle _$EntityGetCircleFromJson(Map<String, dynamic> json) =>
    EntityGetCircle(
      circle: json['circle'] as String?,
      getCircle: json['get_circle'] as String?,
      isNormal: json['is_normal'] as String?,
      median: json['median'] as String?,
      normal: json['normal'] as String?,
      notes: json['notes'] as String?,
      weeks: json['weeks'] as String?,
    );

Map<String, dynamic> _$EntityGetCircleToJson(EntityGetCircle instance) =>
    <String, dynamic>{
      'circle': instance.circle,
      'get_circle': instance.getCircle,
      'is_normal': instance.isNormal,
      'median': instance.median,
      'normal': instance.normal,
      'notes': instance.notes,
      'weeks': instance.weeks,
    };
