// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'account_response_account_me.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

AccountResponseAccountMe _$AccountResponseAccountMeFromJson(
        Map<String, dynamic> json) =>
    AccountResponseAccountMe(
      account: json['account'] == null
          ? null
          : EntityAccountMe.fromJson(json['account'] as Map<String, dynamic>),
    );

Map<String, dynamic> _$AccountResponseAccountMeToJson(
        AccountResponseAccountMe instance) =>
    <String, dynamic>{
      'account': instance.account,
    };
