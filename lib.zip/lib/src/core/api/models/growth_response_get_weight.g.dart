// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'growth_response_get_weight.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

GrowthResponseGetWeight _$GrowthResponseGetWeightFromJson(
        Map<String, dynamic> json) =>
    GrowthResponseGetWeight(
      list: json['list'] == null
          ? null
          : EntityGetWeight.fromJson(json['list'] as Map<String, dynamic>),
    );

Map<String, dynamic> _$GrowthResponseGetWeightToJson(
        GrowthResponseGetWeight instance) =>
    <String, dynamic>{
      'list': instance.list,
    };
