// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'article_get_favorite_article.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

ArticleGetFavoriteArticle _$ArticleGetFavoriteArticleFromJson(
        Map<String, dynamic> json) =>
    ArticleGetFavoriteArticle(
      articles: (json['articles'] as List<dynamic>?)
          ?.map((e) =>
              EntityFavoriteArticleResponse.fromJson(e as Map<String, dynamic>))
          .toList(),
    );

Map<String, dynamic> _$ArticleGetFavoriteArticleToJson(
        ArticleGetFavoriteArticle instance) =>
    <String, dynamic>{
      'articles': instance.articles,
    };
