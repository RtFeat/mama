// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'child_delete_avatar.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

ChildDeleteAvatar _$ChildDeleteAvatarFromJson(Map<String, dynamic> json) =>
    ChildDeleteAvatar(
      childId: json['child_id'] as String,
    );

Map<String, dynamic> _$ChildDeleteAvatarToJson(ChildDeleteAvatar instance) =>
    <String, dynamic>{
      'child_id': instance.childId,
    };
