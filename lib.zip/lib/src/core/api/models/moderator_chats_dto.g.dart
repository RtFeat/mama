// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'moderator_chats_dto.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

ModeratorChatsDto _$ModeratorChatsDtoFromJson(Map<String, dynamic> json) =>
    ModeratorChatsDto(
      accountId: json['account_id'] as String?,
    );

Map<String, dynamic> _$ModeratorChatsDtoToJson(ModeratorChatsDto instance) =>
    <String, dynamic>{
      'account_id': instance.accountId,
    };
