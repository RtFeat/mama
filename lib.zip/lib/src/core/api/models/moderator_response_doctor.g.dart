// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'moderator_response_doctor.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

ModeratorResponseDoctor _$ModeratorResponseDoctorFromJson(
        Map<String, dynamic> json) =>
    ModeratorResponseDoctor(
      doctor: json['doctor'] == null
          ? null
          : EntityDoctorResponse.fromJson(
              json['doctor'] as Map<String, dynamic>),
    );

Map<String, dynamic> _$ModeratorResponseDoctorToJson(
        ModeratorResponseDoctor instance) =>
    <String, dynamic>{
      'doctor': instance.doctor,
    };
