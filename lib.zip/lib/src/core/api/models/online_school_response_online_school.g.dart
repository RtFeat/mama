// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'online_school_response_online_school.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

OnlineSchoolResponseOnlineSchool _$OnlineSchoolResponseOnlineSchoolFromJson(
        Map<String, dynamic> json) =>
    OnlineSchoolResponseOnlineSchool(
      onlineSchool: json['online_school'] == null
          ? null
          : EntityOnlineSchoolResponse.fromJson(
              json['online_school'] as Map<String, dynamic>),
    );

Map<String, dynamic> _$OnlineSchoolResponseOnlineSchoolToJson(
        OnlineSchoolResponseOnlineSchool instance) =>
    <String, dynamic>{
      'online_school': instance.onlineSchool,
    };
