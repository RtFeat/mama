// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'doctor_doctors_response.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

DoctorDoctorsResponse _$DoctorDoctorsResponseFromJson(
        Map<String, dynamic> json) =>
    DoctorDoctorsResponse(
      doctors: (json['doctors'] as List<dynamic>?)
          ?.map((e) => EntityDoctorResponse.fromJson(e as Map<String, dynamic>))
          .toList(),
    );

Map<String, dynamic> _$DoctorDoctorsResponseToJson(
        DoctorDoctorsResponse instance) =>
    <String, dynamic>{
      'doctors': instance.doctors,
    };
