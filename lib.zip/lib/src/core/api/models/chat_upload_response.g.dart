// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'chat_upload_response.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

ChatUploadResponse _$ChatUploadResponseFromJson(Map<String, dynamic> json) =>
    ChatUploadResponse(
      messages: (json['messages'] as List<dynamic>?)
          ?.map((e) => EntityMessageDto.fromJson(e as Map<String, dynamic>))
          .toList(),
    );

Map<String, dynamic> _$ChatUploadResponseToJson(ChatUploadResponse instance) =>
    <String, dynamic>{
      'messages': instance.messages,
    };
