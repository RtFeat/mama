// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'feed_insert_pumping_dto.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

FeedInsertPumpingDto _$FeedInsertPumpingDtoFromJson(
        Map<String, dynamic> json) =>
    FeedInsertPumpingDto(
      all: (json['all'] as num?)?.toInt(),
      childId: json['child_id'] as String?,
      left: (json['left'] as num?)?.toInt(),
      notes: json['notes'] as String?,
      right: (json['right'] as num?)?.toInt(),
      timeToEnd: json['time_to_end'] as String?,
    );

Map<String, dynamic> _$FeedInsertPumpingDtoToJson(
        FeedInsertPumpingDto instance) =>
    <String, dynamic>{
      'all': instance.all,
      'child_id': instance.childId,
      'left': instance.left,
      'notes': instance.notes,
      'right': instance.right,
      'time_to_end': instance.timeToEnd,
    };
