// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'growth_insert_weight_dto.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

GrowthInsertWeightDto _$GrowthInsertWeightDtoFromJson(
        Map<String, dynamic> json) =>
    GrowthInsertWeightDto(
      childId: json['child_id'] as String?,
      createdAt: json['created_at'] as String?,
      notes: json['notes'] as String?,
      weight: json['weight'] as String?,
    );

Map<String, dynamic> _$GrowthInsertWeightDtoToJson(
        GrowthInsertWeightDto instance) =>
    <String, dynamic>{
      'child_id': instance.childId,
      'created_at': instance.createdAt,
      'notes': instance.notes,
      'weight': instance.weight,
    };
