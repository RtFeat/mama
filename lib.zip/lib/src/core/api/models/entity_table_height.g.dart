// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'entity_table_height.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

EntityTableHeight _$EntityTableHeightFromJson(Map<String, dynamic> json) =>
    EntityTableHeight(
      currentHeight: json['current_height'] == null
          ? null
          : EntityCurrentHeight.fromJson(
              json['current_height'] as Map<String, dynamic>),
      dynamicsHeight: json['dynamics_height'] == null
          ? null
          : EntityDynamicsHeight.fromJson(
              json['dynamics_height'] as Map<String, dynamic>),
      table: (json['table'] as List<dynamic>?)
          ?.map((e) =>
              EntityCurrentHeightStruct.fromJson(e as Map<String, dynamic>))
          .toList(),
    );

Map<String, dynamic> _$EntityTableHeightToJson(EntityTableHeight instance) =>
    <String, dynamic>{
      'current_height': instance.currentHeight,
      'dynamics_height': instance.dynamicsHeight,
      'table': instance.table,
    };
