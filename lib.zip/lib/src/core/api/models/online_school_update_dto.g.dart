// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'online_school_update_dto.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

OnlineSchoolUpdateDto _$OnlineSchoolUpdateDtoFromJson(
        Map<String, dynamic> json) =>
    OnlineSchoolUpdateDto(
      email: json['email'] as String?,
      info: json['info'] as String?,
      name: json['name'] as String?,
    );

Map<String, dynamic> _$OnlineSchoolUpdateDtoToJson(
        OnlineSchoolUpdateDto instance) =>
    <String, dynamic>{
      'email': instance.email,
      'info': instance.info,
      'name': instance.name,
    };
