// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'entity_stat_account_buy.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

EntityStatAccountBuy _$EntityStatAccountBuyFromJson(
        Map<String, dynamic> json) =>
    EntityStatAccountBuy(
      countSub: (json['count_sub'] as num?)?.toInt(),
      howMuchSub: json['how_much_sub'] as String?,
      typeSub: json['type_sub'] as String?,
    );

Map<String, dynamic> _$EntityStatAccountBuyToJson(
        EntityStatAccountBuy instance) =>
    <String, dynamic>{
      'count_sub': instance.countSub,
      'how_much_sub': instance.howMuchSub,
      'type_sub': instance.typeSub,
    };
