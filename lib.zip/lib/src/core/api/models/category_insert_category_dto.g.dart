// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'category_insert_category_dto.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

CategoryInsertCategoryDto _$CategoryInsertCategoryDtoFromJson(
        Map<String, dynamic> json) =>
    CategoryInsertCategoryDto(
      name: json['name'] as String?,
    );

Map<String, dynamic> _$CategoryInsertCategoryDtoToJson(
        CategoryInsertCategoryDto instance) =>
    <String, dynamic>{
      'name': instance.name,
    };
