// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'entity_food_history_total.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

EntityFoodHistoryTotal _$EntityFoodHistoryTotalFromJson(
        Map<String, dynamic> json) =>
    EntityFoodHistoryTotal(
      foodHistory: (json['food_history'] as List<dynamic>?)
          ?.map((e) => EntityFoodHistory.fromJson(e as Map<String, dynamic>))
          .toList(),
      object0: json["time_to_end_don't_use"] as String?,
      timeToEndTotal: json['time_to_end_total'] as String?,
      timeToEnd: json['TimeToEnd'] as String?,
      totalChest: (json['total_chest'] as num?)?.toInt(),
      totalMixture: (json['total_mixture'] as num?)?.toInt(),
      totalTotal: (json['total_total'] as num?)?.toInt(),
    );

Map<String, dynamic> _$EntityFoodHistoryTotalToJson(
        EntityFoodHistoryTotal instance) =>
    <String, dynamic>{
      'food_history': instance.foodHistory,
      "time_to_end_don't_use": instance.object0,
      'time_to_end_total': instance.timeToEndTotal,
      'TimeToEnd': instance.timeToEnd,
      'total_chest': instance.totalChest,
      'total_mixture': instance.totalMixture,
      'total_total': instance.totalTotal,
    };
