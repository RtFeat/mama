// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'health_delete_cons_doctor.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

HealthDeleteConsDoctor _$HealthDeleteConsDoctorFromJson(
        Map<String, dynamic> json) =>
    HealthDeleteConsDoctor(
      id: json['id'] as String,
    );

Map<String, dynamic> _$HealthDeleteConsDoctorToJson(
        HealthDeleteConsDoctor instance) =>
    <String, dynamic>{
      'id': instance.id,
    };
