// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'online_school_resp_online_school_course.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

OnlineSchoolRespOnlineSchoolCourse _$OnlineSchoolRespOnlineSchoolCourseFromJson(
        Map<String, dynamic> json) =>
    OnlineSchoolRespOnlineSchoolCourse(
      list: (json['list'] as List<dynamic>?)
          ?.map((e) =>
              EntityOnlineSchoolCourse.fromJson(e as Map<String, dynamic>))
          .toList(),
    );

Map<String, dynamic> _$OnlineSchoolRespOnlineSchoolCourseToJson(
        OnlineSchoolRespOnlineSchoolCourse instance) =>
    <String, dynamic>{
      'list': instance.list,
    };
