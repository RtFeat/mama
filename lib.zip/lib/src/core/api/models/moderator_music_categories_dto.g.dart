// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'moderator_music_categories_dto.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

ModeratorMusicCategoriesDto _$ModeratorMusicCategoriesDtoFromJson(
        Map<String, dynamic> json) =>
    ModeratorMusicCategoriesDto(
      category: json['category'] as String?,
    );

Map<String, dynamic> _$ModeratorMusicCategoriesDtoToJson(
        ModeratorMusicCategoriesDto instance) =>
    <String, dynamic>{
      'category': instance.category,
    };
