// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'entity_article_writer.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

EntityArticleWriter _$EntityArticleWriterFromJson(Map<String, dynamic> json) =>
    EntityArticleWriter(
      accountId: json['account_id'] as String?,
      doctorProfession: json['doctor_profession'] as String?,
      firstName: json['first_name'] as String?,
      lastName: json['last_name'] as String?,
      photoId: json['photo_id'] as String?,
      role: json['role'] == null
          ? null
          : EntityRole.fromJson(json['role'] as String),
    );

Map<String, dynamic> _$EntityArticleWriterToJson(
        EntityArticleWriter instance) =>
    <String, dynamic>{
      'account_id': instance.accountId,
      'doctor_profession': instance.doctorProfession,
      'first_name': instance.firstName,
      'last_name': instance.lastName,
      'photo_id': instance.photoId,
      'role': _$EntityRoleEnumMap[instance.role],
    };

const _$EntityRoleEnumMap = {
  EntityRole.admin: 'ADMIN',
  EntityRole.moderator: 'MODERATOR',
  EntityRole.doctor: 'DOCTOR',
  EntityRole.user: 'USER',
  EntityRole.onlineSchool: 'ONLINE_SCHOOL',
  EntityRole.$unknown: r'$unknown',
};
