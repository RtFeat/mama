// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'friday2.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

Friday2 _$Friday2FromJson(Map<String, dynamic> json) => Friday2(
      consultations: (json['consultations'] as List<dynamic>?)
          ?.map(
              (e) => EntityConsultationSlot.fromJson(e as Map<String, dynamic>))
          .toList(),
      workSlots: (json['work_slots'] as List<dynamic>?)
          ?.map((e) => EntityWorkSlot.fromJson(e as Map<String, dynamic>))
          .toList(),
    );

Map<String, dynamic> _$Friday2ToJson(Friday2 instance) => <String, dynamic>{
      'consultations': instance.consultations,
      'work_slots': instance.workSlots,
    };
