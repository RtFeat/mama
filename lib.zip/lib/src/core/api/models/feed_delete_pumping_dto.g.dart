// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'feed_delete_pumping_dto.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

FeedDeletePumpingDto _$FeedDeletePumpingDtoFromJson(
        Map<String, dynamic> json) =>
    FeedDeletePumpingDto(
      id: json['id'] as String?,
    );

Map<String, dynamic> _$FeedDeletePumpingDtoToJson(
        FeedDeletePumpingDto instance) =>
    <String, dynamic>{
      'id': instance.id,
    };
