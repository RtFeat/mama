// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'growth_delete_circle_dto.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

GrowthDeleteCircleDto _$GrowthDeleteCircleDtoFromJson(
        Map<String, dynamic> json) =>
    GrowthDeleteCircleDto(
      id: json['id'] as String?,
    );

Map<String, dynamic> _$GrowthDeleteCircleDtoToJson(
        GrowthDeleteCircleDto instance) =>
    <String, dynamic>{
      'id': instance.id,
    };
