// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'feedback_chat_response.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

FeedbackChatResponse _$FeedbackChatResponseFromJson(
        Map<String, dynamic> json) =>
    FeedbackChatResponse(
      chat: json['chat'] == null
          ? null
          : EntitySingleChat.fromJson(json['chat'] as Map<String, dynamic>),
    );

Map<String, dynamic> _$FeedbackChatResponseToJson(
        FeedbackChatResponse instance) =>
    <String, dynamic>{
      'chat': instance.chat,
    };
