// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'entity_native_article.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

EntityNativeArticle _$EntityNativeArticleFromJson(Map<String, dynamic> json) =>
    EntityNativeArticle(
      author: json['author'] == null
          ? null
          : EntityAccount.fromJson(json['author'] as Map<String, dynamic>),
      body: (json['body'] as List<dynamic>?)
          ?.map((e) => EntityBodyResponse.fromJson(e as Map<String, dynamic>))
          .toList(),
      title: json['title'] as String?,
    );

Map<String, dynamic> _$EntityNativeArticleToJson(
        EntityNativeArticle instance) =>
    <String, dynamic>{
      'author': instance.author,
      'body': instance.body,
      'title': instance.title,
    };
