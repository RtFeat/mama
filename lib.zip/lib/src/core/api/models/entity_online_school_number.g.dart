// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'entity_online_school_number.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

EntityOnlineSchoolNumber _$EntityOnlineSchoolNumberFromJson(
        Map<String, dynamic> json) =>
    EntityOnlineSchoolNumber(
      id: json['id'] as String?,
      onlineSchoolId: json['online_school_id'] as String?,
      phone: json['phone'] as String?,
    );

Map<String, dynamic> _$EntityOnlineSchoolNumberToJson(
        EntityOnlineSchoolNumber instance) =>
    <String, dynamic>{
      'id': instance.id,
      'online_school_id': instance.onlineSchoolId,
      'phone': instance.phone,
    };
