// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'entity_current_height_struct.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

EntityCurrentHeightStruct _$EntityCurrentHeightStructFromJson(
        Map<String, dynamic> json) =>
    EntityCurrentHeightStruct(
      height: json['height'] as String?,
      time: json['time'] as String?,
    );

Map<String, dynamic> _$EntityCurrentHeightStructToJson(
        EntityCurrentHeightStruct instance) =>
    <String, dynamic>{
      'height': instance.height,
      'time': instance.time,
    };
