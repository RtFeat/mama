// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'moderator_stat_req.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

ModeratorStatReq _$ModeratorStatReqFromJson(Map<String, dynamic> json) =>
    ModeratorStatReq(
      fromTime: json['from_time'] as String?,
      toTime: json['to_time'] as String?,
    );

Map<String, dynamic> _$ModeratorStatReqToJson(ModeratorStatReq instance) =>
    <String, dynamic>{
      'from_time': instance.fromTime,
      'to_time': instance.toTime,
    };
