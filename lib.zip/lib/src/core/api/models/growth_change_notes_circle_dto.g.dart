// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'growth_change_notes_circle_dto.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

GrowthChangeNotesCircleDto _$GrowthChangeNotesCircleDtoFromJson(
        Map<String, dynamic> json) =>
    GrowthChangeNotesCircleDto(
      id: json['id'] as String?,
      notes: json['notes'] as String?,
    );

Map<String, dynamic> _$GrowthChangeNotesCircleDtoToJson(
        GrowthChangeNotesCircleDto instance) =>
    <String, dynamic>{
      'id': instance.id,
      'notes': instance.notes,
    };
