// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'moderator_me_response.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

ModeratorMeResponse _$ModeratorMeResponseFromJson(Map<String, dynamic> json) =>
    ModeratorMeResponse(
      account: json['account'] == null
          ? null
          : EntityAccount.fromJson(json['account'] as Map<String, dynamic>),
    );

Map<String, dynamic> _$ModeratorMeResponseToJson(
        ModeratorMeResponse instance) =>
    <String, dynamic>{
      'account': instance.account,
    };
