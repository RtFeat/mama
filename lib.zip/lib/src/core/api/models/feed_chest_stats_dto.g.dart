// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'feed_chest_stats_dto.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

FeedChestStatsDto _$FeedChestStatsDtoFromJson(Map<String, dynamic> json) =>
    FeedChestStatsDto(
      id: json['id'] as String,
      left: (json['left'] as num).toInt(),
      right: (json['right'] as num).toInt(),
      timeToEnd: json['timeToEnd'] as String,
    );

Map<String, dynamic> _$FeedChestStatsDtoToJson(FeedChestStatsDto instance) =>
    <String, dynamic>{
      'id': instance.id,
      'left': instance.left,
      'right': instance.right,
      'timeToEnd': instance.timeToEnd,
    };
