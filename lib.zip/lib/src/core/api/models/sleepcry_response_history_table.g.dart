// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'sleepcry_response_history_table.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

SleepcryResponseHistoryTable _$SleepcryResponseHistoryTableFromJson(
        Map<String, dynamic> json) =>
    SleepcryResponseHistoryTable(
      list: (json['list'] as List<dynamic>?)
          ?.map((e) =>
              EntityTableSleepCryTotal.fromJson(e as Map<String, dynamic>))
          .toList(),
    );

Map<String, dynamic> _$SleepcryResponseHistoryTableToJson(
        SleepcryResponseHistoryTable instance) =>
    <String, dynamic>{
      'list': instance.list,
    };
