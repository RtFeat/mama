// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'health_response_doc_vaccination.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

HealthResponseDocVaccination _$HealthResponseDocVaccinationFromJson(
        Map<String, dynamic> json) =>
    HealthResponseDocVaccination(
      id: json['id'] as String?,
      photo: json['photo'] as String?,
    );

Map<String, dynamic> _$HealthResponseDocVaccinationToJson(
        HealthResponseDocVaccination instance) =>
    <String, dynamic>{
      'id': instance.id,
      'photo': instance.photo,
    };
