// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'article_article_response.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

ArticleArticleResponse _$ArticleArticleResponseFromJson(
        Map<String, dynamic> json) =>
    ArticleArticleResponse(
      article: json['article'] == null
          ? null
          : EntityArticleResponse.fromJson(
              json['article'] as Map<String, dynamic>),
    );

Map<String, dynamic> _$ArticleArticleResponseToJson(
        ArticleArticleResponse instance) =>
    <String, dynamic>{
      'article': instance.article,
    };
