// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'entity_promocode.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

EntityPromocode _$EntityPromocodeFromJson(Map<String, dynamic> json) =>
    EntityPromocode(
      countPromo: (json['count_promo'] as num?)?.toInt(),
      createdAt: json['created_at'] as String?,
      id: json['id'] as String?,
      name: json['name'] as String?,
      status: json['status'] as String?,
      typePromo: json['type_promo'] as String?,
      usedAt: json['used_at'] as String?,
    );

Map<String, dynamic> _$EntityPromocodeToJson(EntityPromocode instance) =>
    <String, dynamic>{
      'count_promo': instance.countPromo,
      'created_at': instance.createdAt,
      'id': instance.id,
      'name': instance.name,
      'status': instance.status,
      'type_promo': instance.typePromo,
      'used_at': instance.usedAt,
    };
