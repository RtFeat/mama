// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'article_count_article_cat.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

ArticleCountArticleCat _$ArticleCountArticleCatFromJson(
        Map<String, dynamic> json) =>
    ArticleCountArticleCat(
      list: (json['list'] as Map<String, dynamic>?)?.map(
        (k, e) => MapEntry(k, (e as num).toInt()),
      ),
    );

Map<String, dynamic> _$ArticleCountArticleCatToJson(
        ArticleCountArticleCat instance) =>
    <String, dynamic>{
      'list': instance.list,
    };
