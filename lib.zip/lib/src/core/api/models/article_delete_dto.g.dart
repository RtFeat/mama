// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'article_delete_dto.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

ArticleDeleteDto _$ArticleDeleteDtoFromJson(Map<String, dynamic> json) =>
    ArticleDeleteDto(
      photoId: json['photo_id'] as String,
    );

Map<String, dynamic> _$ArticleDeleteDtoToJson(ArticleDeleteDto instance) =>
    <String, dynamic>{
      'photo_id': instance.photoId,
    };
