// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'entity_list_article_response.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

EntityListArticleResponse _$EntityListArticleResponseFromJson(
        Map<String, dynamic> json) =>
    EntityListArticleResponse(
      ageCategory: (json['age_category'] as List<dynamic>?)
          ?.map((e) => e as String)
          .toList(),
      category: json['category'] as String?,
      id: json['id'] as String?,
      photoId: json['photo_id'] as String?,
      photoUrl: json['photo_url'] as String?,
      title: json['title'] as String?,
    );

Map<String, dynamic> _$EntityListArticleResponseToJson(
        EntityListArticleResponse instance) =>
    <String, dynamic>{
      'age_category': instance.ageCategory,
      'category': instance.category,
      'id': instance.id,
      'photo_id': instance.photoId,
      'photo_url': instance.photoUrl,
      'title': instance.title,
    };
