// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'entity_message_dto.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

EntityMessageDto _$EntityMessageDtoFromJson(Map<String, dynamic> json) =>
    EntityMessageDto(
      filePath: json['file_path'] as String?,
      filename: json['filename'] as String?,
      typeFile: json['type_file'] as String?,
    );

Map<String, dynamic> _$EntityMessageDtoToJson(EntityMessageDto instance) =>
    <String, dynamic>{
      'file_path': instance.filePath,
      'filename': instance.filename,
      'type_file': instance.typeFile,
    };
