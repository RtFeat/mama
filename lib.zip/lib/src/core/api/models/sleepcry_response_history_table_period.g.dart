// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'sleepcry_response_history_table_period.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

SleepcryResponseHistoryTablePeriod _$SleepcryResponseHistoryTablePeriodFromJson(
        Map<String, dynamic> json) =>
    SleepcryResponseHistoryTablePeriod(
      list: json['list'] == null
          ? null
          : EntityCryAndSleep.fromJson(json['list'] as Map<String, dynamic>),
    );

Map<String, dynamic> _$SleepcryResponseHistoryTablePeriodToJson(
        SleepcryResponseHistoryTablePeriod instance) =>
    <String, dynamic>{
      'list': instance.list,
    };
