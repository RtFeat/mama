// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'notification_notifications_response.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

NotificationNotificationsResponse _$NotificationNotificationsResponseFromJson(
        Map<String, dynamic> json) =>
    NotificationNotificationsResponse(
      notifications: (json['notifications'] as List<dynamic>?)
          ?.map((e) => EntityNotification.fromJson(e as Map<String, dynamic>))
          .toList(),
    );

Map<String, dynamic> _$NotificationNotificationsResponseToJson(
        NotificationNotificationsResponse instance) =>
    <String, dynamic>{
      'notifications': instance.notifications,
    };
