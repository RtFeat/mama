// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'entity_account.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

EntityAccount _$EntityAccountFromJson(Map<String, dynamic> json) =>
    EntityAccount(
      avatar: json['avatar'] as String?,
      createdAt: json['created_at'] as String?,
      email: json['email'] as String?,
      favoriteArticle: json['favorite_article'] as String?,
      firstName: json['first_name'] as String?,
      gender: json['gender'] == null
          ? null
          : EntityGender.fromJson(json['gender'] as String),
      id: json['id'] as String?,
      info: json['info'] as String?,
      isDeleted: json['is_deleted'] as bool?,
      lastActiveAt: json['last_active_at'] as String?,
      lastName: json['last_name'] as String?,
      online: json['online'] as bool?,
      phone: json['phone'] as String?,
      profession: json['profession'] as String?,
      role: json['role'] == null
          ? null
          : EntityRole.fromJson(json['role'] as String),
      secondName: json['second_name'] as String?,
      state: json['state'] == null
          ? null
          : EntityState.fromJson(json['state'] as String),
      status: json['status'] == null
          ? null
          : EntityStatus.fromJson(json['status'] as String),
      updatedAt: json['updated_at'] as String?,
    );

Map<String, dynamic> _$EntityAccountToJson(EntityAccount instance) =>
    <String, dynamic>{
      'avatar': instance.avatar,
      'created_at': instance.createdAt,
      'email': instance.email,
      'favorite_article': instance.favoriteArticle,
      'first_name': instance.firstName,
      'gender': _$EntityGenderEnumMap[instance.gender],
      'id': instance.id,
      'info': instance.info,
      'is_deleted': instance.isDeleted,
      'last_active_at': instance.lastActiveAt,
      'last_name': instance.lastName,
      'online': instance.online,
      'phone': instance.phone,
      'profession': instance.profession,
      'role': _$EntityRoleEnumMap[instance.role],
      'second_name': instance.secondName,
      'state': _$EntityStateEnumMap[instance.state],
      'status': _$EntityStatusEnumMap[instance.status],
      'updated_at': instance.updatedAt,
    };

const _$EntityGenderEnumMap = {
  EntityGender.male: 'MALE',
  EntityGender.female: 'FEMALE',
  EntityGender.$unknown: r'$unknown',
};

const _$EntityRoleEnumMap = {
  EntityRole.admin: 'ADMIN',
  EntityRole.moderator: 'MODERATOR',
  EntityRole.doctor: 'DOCTOR',
  EntityRole.user: 'USER',
  EntityRole.onlineSchool: 'ONLINE_SCHOOL',
  EntityRole.$unknown: r'$unknown',
};

const _$EntityStateEnumMap = {
  EntityState.active: 'ACTIVE',
  EntityState.inactive: 'INACTIVE',
  EntityState.deleted: 'DELETED',
  EntityState.blocked: 'BLOCKED',
  EntityState.unregistered: 'UNREGISTERED',
  EntityState.$unknown: r'$unknown',
};

const _$EntityStatusEnumMap = {
  EntityStatus.subscribed: 'SUBSCRIBED',
  EntityStatus.promoCode: 'PROMO_CODE',
  EntityStatus.trial: 'TRIAL',
  EntityStatus.nOSubscribed: 'NO_SUBSCRIBED',
  EntityStatus.deleted: 'DELETED',
  EntityStatus.$unknown: r'$unknown',
};
