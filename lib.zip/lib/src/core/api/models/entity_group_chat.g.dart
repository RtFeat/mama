// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'entity_group_chat.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

EntityGroupChat _$EntityGroupChatFromJson(Map<String, dynamic> json) =>
    EntityGroupChat(
      canDelete: json['can_delete'] as bool?,
      createdAt: json['created_at'] as String?,
      groupChat: json['group_chat'] == null
          ? null
          : EntityGroupsChat.fromJson(
              json['group_chat'] as Map<String, dynamic>),
      id: json['id'] as String?,
      idGroupChat: json['id_group_chat'] as String?,
      idParticipant: json['id_participant'] as String?,
      isDeleted: json['is_deleted'] as bool?,
      isWrite: json['is_write'] as bool?,
      lastMessage: json['last_message'] == null
          ? null
          : EntityMessage.fromJson(
              json['last_message'] as Map<String, dynamic>),
      lastMessageAt: json['last_message_at'] as String?,
      participant: json['participant'] == null
          ? null
          : EntityAccount.fromJson(json['participant'] as Map<String, dynamic>),
      unreadMessages: (json['unread_messages'] as num?)?.toInt(),
      updatedAt: json['updated_at'] as String?,
    );

Map<String, dynamic> _$EntityGroupChatToJson(EntityGroupChat instance) =>
    <String, dynamic>{
      'can_delete': instance.canDelete,
      'created_at': instance.createdAt,
      'group_chat': instance.groupChat,
      'id': instance.id,
      'id_group_chat': instance.idGroupChat,
      'id_participant': instance.idParticipant,
      'is_deleted': instance.isDeleted,
      'is_write': instance.isWrite,
      'last_message': instance.lastMessage,
      'last_message_at': instance.lastMessageAt,
      'participant': instance.participant,
      'unread_messages': instance.unreadMessages,
      'updated_at': instance.updatedAt,
    };
