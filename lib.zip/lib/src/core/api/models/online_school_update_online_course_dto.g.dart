// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'online_school_update_online_course_dto.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

OnlineSchoolUpdateOnlineCourseDto _$OnlineSchoolUpdateOnlineCourseDtoFromJson(
        Map<String, dynamic> json) =>
    OnlineSchoolUpdateOnlineCourseDto(
      id: json['id'] as String?,
      link: json['link'] as String?,
      shortDescription: json['short_description'] as String?,
      title: json['title'] as String?,
    );

Map<String, dynamic> _$OnlineSchoolUpdateOnlineCourseDtoToJson(
        OnlineSchoolUpdateOnlineCourseDto instance) =>
    <String, dynamic>{
      'id': instance.id,
      'link': instance.link,
      'short_description': instance.shortDescription,
      'title': instance.title,
    };
