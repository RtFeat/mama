// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'sleepcry_response_history_cry.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

SleepcryResponseHistoryCry _$SleepcryResponseHistoryCryFromJson(
        Map<String, dynamic> json) =>
    SleepcryResponseHistoryCry(
      list: (json['list'] as List<dynamic>?)
          ?.map(
              (e) => EntityCryHistoryTotal.fromJson(e as Map<String, dynamic>))
          .toList(),
    );

Map<String, dynamic> _$SleepcryResponseHistoryCryToJson(
        SleepcryResponseHistoryCry instance) =>
    <String, dynamic>{
      'list': instance.list,
    };
