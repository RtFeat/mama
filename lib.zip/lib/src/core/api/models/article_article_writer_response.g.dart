// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'article_article_writer_response.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

ArticleArticleWriterResponse _$ArticleArticleWriterResponseFromJson(
        Map<String, dynamic> json) =>
    ArticleArticleWriterResponse(
      list: (json['list'] as List<dynamic>?)
          ?.map((e) => ArticleArticleWriter.fromJson(e as Map<String, dynamic>))
          .toList(),
    );

Map<String, dynamic> _$ArticleArticleWriterResponseToJson(
        ArticleArticleWriterResponse instance) =>
    <String, dynamic>{
      'list': instance.list,
    };
