// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'entity_chest_history_total.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

EntityChestHistoryTotal _$EntityChestHistoryTotalFromJson(
        Map<String, dynamic> json) =>
    EntityChestHistoryTotal(
      chestHistory: (json['chest_history'] as List<dynamic>?)
          ?.map((e) => EntityChestHistory.fromJson(e as Map<String, dynamic>))
          .toList(),
      timeToEndDontUse: json['time_to_end_dont_use'] as String?,
      timeToEndTotal: json['time_to_end_total'] as String?,
      totalLeft: (json['total_left'] as num?)?.toInt(),
      totalMinutes: (json['total_minutes'] as num?)?.toInt(),
      totalRight: (json['total_right'] as num?)?.toInt(),
    );

Map<String, dynamic> _$EntityChestHistoryTotalToJson(
        EntityChestHistoryTotal instance) =>
    <String, dynamic>{
      'chest_history': instance.chestHistory,
      'time_to_end_dont_use': instance.timeToEndDontUse,
      'time_to_end_total': instance.timeToEndTotal,
      'total_left': instance.totalLeft,
      'total_minutes': instance.totalMinutes,
      'total_right': instance.totalRight,
    };
