// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'feed_get_food_response.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

FeedGetFoodResponse _$FeedGetFoodResponseFromJson(Map<String, dynamic> json) =>
    FeedGetFoodResponse(
      list: (json['list'] as List<dynamic>?)
          ?.map((e) => EntityFood.fromJson(e as Map<String, dynamic>))
          .toList(),
    );

Map<String, dynamic> _$FeedGetFoodResponseToJson(
        FeedGetFoodResponse instance) =>
    <String, dynamic>{
      'list': instance.list,
    };
