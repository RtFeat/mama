// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'consultation_update_dto.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

ConsultationUpdateDto _$ConsultationUpdateDtoFromJson(
        Map<String, dynamic> json) =>
    ConsultationUpdateDto(
      doctorId: json['doctor_id'] as String?,
      status: json['status'] as String?,
      timeBegin: json['time_begin'] as String?,
      type: json['type'] as String?,
      userId: json['user_id'] as String?,
    );

Map<String, dynamic> _$ConsultationUpdateDtoToJson(
        ConsultationUpdateDto instance) =>
    <String, dynamic>{
      'doctor_id': instance.doctorId,
      'status': instance.status,
      'time_begin': instance.timeBegin,
      'type': instance.type,
      'user_id': instance.userId,
    };
