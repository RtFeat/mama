// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'online_school_req_add_online_school.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

OnlineSchoolReqAddOnlineSchool _$OnlineSchoolReqAddOnlineSchoolFromJson(
        Map<String, dynamic> json) =>
    OnlineSchoolReqAddOnlineSchool(
      link: json['link'] as String?,
      onlineSchoolId: json['online_school_id'] as String?,
      shortDescription: json['short_description'] as String?,
      title: json['title'] as String?,
    );

Map<String, dynamic> _$OnlineSchoolReqAddOnlineSchoolToJson(
        OnlineSchoolReqAddOnlineSchool instance) =>
    <String, dynamic>{
      'link': instance.link,
      'online_school_id': instance.onlineSchoolId,
      'short_description': instance.shortDescription,
      'title': instance.title,
    };
