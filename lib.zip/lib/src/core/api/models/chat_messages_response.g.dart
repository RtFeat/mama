// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'chat_messages_response.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

ChatMessagesResponse _$ChatMessagesResponseFromJson(
        Map<String, dynamic> json) =>
    ChatMessagesResponse(
      attached: (json['attached'] as List<dynamic>?)
          ?.map((e) => e as String)
          .toList(),
      messages: (json['messages'] as List<dynamic>?)
          ?.map((e) => EntityMessageResp.fromJson(e as Map<String, dynamic>))
          .toList(),
    );

Map<String, dynamic> _$ChatMessagesResponseToJson(
        ChatMessagesResponse instance) =>
    <String, dynamic>{
      'attached': instance.attached,
      'messages': instance.messages,
    };
