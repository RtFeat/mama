// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'diapers_create_diaper_dto.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

DiapersCreateDiaperDto _$DiapersCreateDiaperDtoFromJson(
        Map<String, dynamic> json) =>
    DiapersCreateDiaperDto(
      childId: json['child_id'] as String?,
      howMuch: json['how_much'] as String?,
      notes: json['notes'] as String?,
      timeToEnd: json['time_to_end'] as String?,
      typeOfDiapers: json['type_of_diapers'] as String?,
    );

Map<String, dynamic> _$DiapersCreateDiaperDtoToJson(
        DiapersCreateDiaperDto instance) =>
    <String, dynamic>{
      'child_id': instance.childId,
      'how_much': instance.howMuch,
      'notes': instance.notes,
      'time_to_end': instance.timeToEnd,
      'type_of_diapers': instance.typeOfDiapers,
    };
