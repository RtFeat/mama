// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'health_delete_drug.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

HealthDeleteDrug _$HealthDeleteDrugFromJson(Map<String, dynamic> json) =>
    HealthDeleteDrug(
      id: json['id'] as String,
    );

Map<String, dynamic> _$HealthDeleteDrugToJson(HealthDeleteDrug instance) =>
    <String, dynamic>{
      'id': instance.id,
    };
