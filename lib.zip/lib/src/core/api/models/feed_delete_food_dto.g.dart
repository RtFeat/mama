// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'feed_delete_food_dto.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

FeedDeleteFoodDto _$FeedDeleteFoodDtoFromJson(Map<String, dynamic> json) =>
    FeedDeleteFoodDto(
      id: json['id'] as String,
    );

Map<String, dynamic> _$FeedDeleteFoodDtoToJson(FeedDeleteFoodDto instance) =>
    <String, dynamic>{
      'id': instance.id,
    };
