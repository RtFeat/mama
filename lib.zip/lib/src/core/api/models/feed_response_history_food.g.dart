// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'feed_response_history_food.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

FeedResponseHistoryFood _$FeedResponseHistoryFoodFromJson(
        Map<String, dynamic> json) =>
    FeedResponseHistoryFood(
      list: (json['list'] as List<dynamic>?)
          ?.map(
              (e) => EntityFoodHistoryTotal.fromJson(e as Map<String, dynamic>))
          .toList(),
    );

Map<String, dynamic> _$FeedResponseHistoryFoodToJson(
        FeedResponseHistoryFood instance) =>
    <String, dynamic>{
      'list': instance.list,
    };
