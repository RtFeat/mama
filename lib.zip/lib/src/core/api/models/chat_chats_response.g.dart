// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'chat_chats_response.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

ChatChatsResponse _$ChatChatsResponseFromJson(Map<String, dynamic> json) =>
    ChatChatsResponse(
      chats: (json['chats'] as List<dynamic>?)
          ?.map((e) => EntitySingleChat.fromJson(e as Map<String, dynamic>))
          .toList(),
    );

Map<String, dynamic> _$ChatChatsResponseToJson(ChatChatsResponse instance) =>
    <String, dynamic>{
      'chats': instance.chats,
    };
