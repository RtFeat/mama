// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'entity_notification.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

EntityNotification _$EntityNotificationFromJson(Map<String, dynamic> json) =>
    EntityNotification(
      createdAt: json['created_at'] as String?,
      id: json['id'] as String?,
      metadata: json['metadata'],
      read: json['read'] as bool?,
      text: json['text'] as String?,
      type: json['type'] as String?,
      userId: json['user_id'] as String?,
    );

Map<String, dynamic> _$EntityNotificationToJson(EntityNotification instance) =>
    <String, dynamic>{
      'created_at': instance.createdAt,
      'id': instance.id,
      'metadata': instance.metadata,
      'read': instance.read,
      'text': instance.text,
      'type': instance.type,
      'user_id': instance.userId,
    };
