// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'entity_doctor_work_time_response.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

EntityDoctorWorkTimeResponse _$EntityDoctorWorkTimeResponseFromJson(
        Map<String, dynamic> json) =>
    EntityDoctorWorkTimeResponse(
      accountId: json['account_id'] as String?,
      friday: json['friday'] == null
          ? null
          : Friday2.fromJson(json['friday'] as Map<String, dynamic>),
      id: json['id'] as String?,
      monday: json['monday'] == null
          ? null
          : Monday2.fromJson(json['monday'] as Map<String, dynamic>),
      saturday: json['saturday'] == null
          ? null
          : Saturday2.fromJson(json['saturday'] as Map<String, dynamic>),
      sunday: json['sunday'] == null
          ? null
          : Sunday2.fromJson(json['sunday'] as Map<String, dynamic>),
      thursday: json['thursday'] == null
          ? null
          : Thursday2.fromJson(json['thursday'] as Map<String, dynamic>),
      tuesday: json['tuesday'] == null
          ? null
          : Tuesday2.fromJson(json['tuesday'] as Map<String, dynamic>),
      wednesday: json['wednesday'] == null
          ? null
          : Wednesday2.fromJson(json['wednesday'] as Map<String, dynamic>),
      weekStart: json['week_start'] as String?,
    );

Map<String, dynamic> _$EntityDoctorWorkTimeResponseToJson(
        EntityDoctorWorkTimeResponse instance) =>
    <String, dynamic>{
      'account_id': instance.accountId,
      'friday': instance.friday,
      'id': instance.id,
      'monday': instance.monday,
      'saturday': instance.saturday,
      'sunday': instance.sunday,
      'thursday': instance.thursday,
      'tuesday': instance.tuesday,
      'wednesday': instance.wednesday,
      'week_start': instance.weekStart,
    };
