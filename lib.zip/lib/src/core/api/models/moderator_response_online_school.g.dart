// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'moderator_response_online_school.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

ModeratorResponseOnlineSchool _$ModeratorResponseOnlineSchoolFromJson(
        Map<String, dynamic> json) =>
    ModeratorResponseOnlineSchool(
      onlineSchool: json['online_school'] == null
          ? null
          : EntityOnlineSchoolResponse.fromJson(
              json['online_school'] as Map<String, dynamic>),
    );

Map<String, dynamic> _$ModeratorResponseOnlineSchoolToJson(
        ModeratorResponseOnlineSchool instance) =>
    <String, dynamic>{
      'online_school': instance.onlineSchool,
    };
