// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'child_update_avatar_response.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

ChildUpdateAvatarResponse _$ChildUpdateAvatarResponseFromJson(
        Map<String, dynamic> json) =>
    ChildUpdateAvatarResponse(
      avatar: json['avatar'] as String?,
    );

Map<String, dynamic> _$ChildUpdateAvatarResponseToJson(
        ChildUpdateAvatarResponse instance) =>
    <String, dynamic>{
      'avatar': instance.avatar,
    };
