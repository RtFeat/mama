// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'entity_current_circle_struct.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

EntityCurrentCircleStruct _$EntityCurrentCircleStructFromJson(
        Map<String, dynamic> json) =>
    EntityCurrentCircleStruct(
      circle: json['circle'] as String?,
      time: json['time'] as String?,
    );

Map<String, dynamic> _$EntityCurrentCircleStructToJson(
        EntityCurrentCircleStruct instance) =>
    <String, dynamic>{
      'circle': instance.circle,
      'time': instance.time,
    };
