// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'entity_consultation_slot.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

EntityConsultationSlot _$EntityConsultationSlotFromJson(
        Map<String, dynamic> json) =>
    EntityConsultationSlot(
      consultationId: json['consultation_id'] as String?,
      consultationTime: json['consultation_time'] as String?,
      consultationType: json['consultation_type'] as String?,
      patientFullName: json['patient_full_name'] as String?,
    );

Map<String, dynamic> _$EntityConsultationSlotToJson(
        EntityConsultationSlot instance) =>
    <String, dynamic>{
      'consultation_id': instance.consultationId,
      'consultation_time': instance.consultationTime,
      'consultation_type': instance.consultationType,
      'patient_full_name': instance.patientFullName,
    };
