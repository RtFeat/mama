// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'geo_cities_response.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

GeoCitiesResponse _$GeoCitiesResponseFromJson(Map<String, dynamic> json) =>
    GeoCitiesResponse(
      cities: (json['cities'] as List<dynamic>?)
          ?.map((e) => EntityCity.fromJson(e as Map<String, dynamic>))
          .toList(),
    );

Map<String, dynamic> _$GeoCitiesResponseToJson(GeoCitiesResponse instance) =>
    <String, dynamic>{
      'cities': instance.cities,
    };
