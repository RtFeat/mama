// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'sleepcry_response_history_sleep.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

SleepcryResponseHistorySleep _$SleepcryResponseHistorySleepFromJson(
        Map<String, dynamic> json) =>
    SleepcryResponseHistorySleep(
      list: (json['list'] as List<dynamic>?)
          ?.map((e) =>
              EntitySleepHistoryTotal.fromJson(e as Map<String, dynamic>))
          .toList(),
    );

Map<String, dynamic> _$SleepcryResponseHistorySleepToJson(
        SleepcryResponseHistorySleep instance) =>
    <String, dynamic>{
      'list': instance.list,
    };
