// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'growth_change_stats_height_dto.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

GrowthChangeStatsHeightDto _$GrowthChangeStatsHeightDtoFromJson(
        Map<String, dynamic> json) =>
    GrowthChangeStatsHeightDto(
      stats: json['stats'] == null
          ? null
          : EntityHeight.fromJson(json['stats'] as Map<String, dynamic>),
    );

Map<String, dynamic> _$GrowthChangeStatsHeightDtoToJson(
        GrowthChangeStatsHeightDto instance) =>
    <String, dynamic>{
      'stats': instance.stats,
    };
