// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'auth_update_phone_dto.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

AuthUpdatePhoneDto _$AuthUpdatePhoneDtoFromJson(Map<String, dynamic> json) =>
    AuthUpdatePhoneDto(
      code: json['code'] as String,
      phone: json['phone'] as String,
    );

Map<String, dynamic> _$AuthUpdatePhoneDtoToJson(AuthUpdatePhoneDto instance) =>
    <String, dynamic>{
      'code': instance.code,
      'phone': instance.phone,
    };
