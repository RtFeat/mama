// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'feed_response_history_pumping.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

FeedResponseHistoryPumping _$FeedResponseHistoryPumpingFromJson(
        Map<String, dynamic> json) =>
    FeedResponseHistoryPumping(
      list: (json['list'] as List<dynamic>?)
          ?.map((e) =>
              EntityPumpingHistoryTotal.fromJson(e as Map<String, dynamic>))
          .toList(),
    );

Map<String, dynamic> _$FeedResponseHistoryPumpingToJson(
        FeedResponseHistoryPumping instance) =>
    <String, dynamic>{
      'list': instance.list,
    };
