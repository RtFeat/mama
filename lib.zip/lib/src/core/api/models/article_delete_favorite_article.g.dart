// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'article_delete_favorite_article.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

ArticleDeleteFavoriteArticle _$ArticleDeleteFavoriteArticleFromJson(
        Map<String, dynamic> json) =>
    ArticleDeleteFavoriteArticle(
      articleId: json['article_id'] as String?,
    );

Map<String, dynamic> _$ArticleDeleteFavoriteArticleToJson(
        ArticleDeleteFavoriteArticle instance) =>
    <String, dynamic>{
      'article_id': instance.articleId,
    };
