// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'growth_response_get_height.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

GrowthResponseGetHeight _$GrowthResponseGetHeightFromJson(
        Map<String, dynamic> json) =>
    GrowthResponseGetHeight(
      list: json['list'] == null
          ? null
          : EntityGetHeight.fromJson(json['list'] as Map<String, dynamic>),
    );

Map<String, dynamic> _$GrowthResponseGetHeightToJson(
        GrowthResponseGetHeight instance) =>
    <String, dynamic>{
      'list': instance.list,
    };
