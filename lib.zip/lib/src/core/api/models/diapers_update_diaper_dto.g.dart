// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'diapers_update_diaper_dto.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

DiapersUpdateDiaperDto _$DiapersUpdateDiaperDtoFromJson(
        Map<String, dynamic> json) =>
    DiapersUpdateDiaperDto(
      howMuch: json['how_much'] as String?,
      id: json['id'] as String?,
      notes: json['notes'] as String?,
      timeToEnd: json['time_to_end'] as String?,
      typeOfDiapers: json['type_of_diapers'] as String?,
    );

Map<String, dynamic> _$DiapersUpdateDiaperDtoToJson(
        DiapersUpdateDiaperDto instance) =>
    <String, dynamic>{
      'how_much': instance.howMuch,
      'id': instance.id,
      'notes': instance.notes,
      'time_to_end': instance.timeToEnd,
      'type_of_diapers': instance.typeOfDiapers,
    };
