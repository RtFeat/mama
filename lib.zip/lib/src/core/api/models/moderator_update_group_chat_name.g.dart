// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'moderator_update_group_chat_name.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

ModeratorUpdateGroupChatName _$ModeratorUpdateGroupChatNameFromJson(
        Map<String, dynamic> json) =>
    ModeratorUpdateGroupChatName(
      chatId: json['chat_id'] as String?,
      newName: json['new_name'] as String?,
    );

Map<String, dynamic> _$ModeratorUpdateGroupChatNameToJson(
        ModeratorUpdateGroupChatName instance) =>
    <String, dynamic>{
      'chat_id': instance.chatId,
      'new_name': instance.newName,
    };
