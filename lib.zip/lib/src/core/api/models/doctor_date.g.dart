// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'doctor_date.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

DoctorDate _$DoctorDateFromJson(Map<String, dynamic> json) => DoctorDate(
      date: json['date'] as String?,
    );

Map<String, dynamic> _$DoctorDateToJson(DoctorDate instance) =>
    <String, dynamic>{
      'date': instance.date,
    };
