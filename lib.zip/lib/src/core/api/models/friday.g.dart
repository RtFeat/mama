// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'friday.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

Friday _$FridayFromJson(Map<String, dynamic> json) => Friday(
      workSlots: (json['work_slots'] as List<dynamic>?)
          ?.map((e) => WorkSlots.fromJson(e as Map<String, dynamic>))
          .toList(),
    );

Map<String, dynamic> _$FridayToJson(Friday instance) => <String, dynamic>{
      'work_slots': instance.workSlots,
    };
