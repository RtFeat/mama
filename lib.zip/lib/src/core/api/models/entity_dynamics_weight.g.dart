// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'entity_dynamics_weight.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

EntityDynamicsWeight _$EntityDynamicsWeightFromJson(
        Map<String, dynamic> json) =>
    EntityDynamicsWeight(
      days: json['days'] as String?,
      timeDuration: json['time_duration'] as String?,
      weightGain: json['weight_gain'] as String?,
      weightToDay: json['weight_to_day'] as String?,
    );

Map<String, dynamic> _$EntityDynamicsWeightToJson(
        EntityDynamicsWeight instance) =>
    <String, dynamic>{
      'days': instance.days,
      'time_duration': instance.timeDuration,
      'weight_gain': instance.weightGain,
      'weight_to_day': instance.weightToDay,
    };
