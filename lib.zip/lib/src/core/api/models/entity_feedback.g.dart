// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'entity_feedback.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

EntityFeedback _$EntityFeedbackFromJson(Map<String, dynamic> json) =>
    EntityFeedback(
      account: json['account'] == null
          ? null
          : EntityAccount.fromJson(json['account'] as Map<String, dynamic>),
      accountId: json['account_id'] as String?,
      createdAt: json['created_at'] as String?,
      id: json['id'] as String?,
      status: json['status'] as String?,
      text: json['text'] as String?,
      type: json['type'] as String?,
    );

Map<String, dynamic> _$EntityFeedbackToJson(EntityFeedback instance) =>
    <String, dynamic>{
      'account': instance.account,
      'account_id': instance.accountId,
      'created_at': instance.createdAt,
      'id': instance.id,
      'status': instance.status,
      'text': instance.text,
      'type': instance.type,
    };
