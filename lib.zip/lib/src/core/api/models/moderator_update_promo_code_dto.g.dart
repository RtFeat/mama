// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'moderator_update_promo_code_dto.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

ModeratorUpdatePromoCodeDto _$ModeratorUpdatePromoCodeDtoFromJson(
        Map<String, dynamic> json) =>
    ModeratorUpdatePromoCodeDto(
      id: json['id'] as String?,
      status: json['status'] as String?,
      type: json['type'] as String?,
    );

Map<String, dynamic> _$ModeratorUpdatePromoCodeDtoToJson(
        ModeratorUpdatePromoCodeDto instance) =>
    <String, dynamic>{
      'id': instance.id,
      'status': instance.status,
      'type': instance.type,
    };
