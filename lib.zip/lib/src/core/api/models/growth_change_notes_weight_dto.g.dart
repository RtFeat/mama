// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'growth_change_notes_weight_dto.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

GrowthChangeNotesWeightDto _$GrowthChangeNotesWeightDtoFromJson(
        Map<String, dynamic> json) =>
    GrowthChangeNotesWeightDto(
      id: json['id'] as String?,
      notes: json['notes'] as String?,
    );

Map<String, dynamic> _$GrowthChangeNotesWeightDtoToJson(
        GrowthChangeNotesWeightDto instance) =>
    <String, dynamic>{
      'id': instance.id,
      'notes': instance.notes,
    };
