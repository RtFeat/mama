// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'entity_sleep_history.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

EntitySleepHistory _$EntitySleepHistoryFromJson(Map<String, dynamic> json) =>
    EntitySleepHistory(
      notes: json['notes'] as String?,
      timeAll: json['time_all'] as String?,
      timeEnd: json['time_end'] as String?,
      timeStart: json['time_start'] as String?,
    );

Map<String, dynamic> _$EntitySleepHistoryToJson(EntitySleepHistory instance) =>
    <String, dynamic>{
      'notes': instance.notes,
      'time_all': instance.timeAll,
      'time_end': instance.timeEnd,
      'time_start': instance.timeStart,
    };
