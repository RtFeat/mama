// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'saturday.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

Saturday _$SaturdayFromJson(Map<String, dynamic> json) => Saturday(
      workSlots: (json['work_slots'] as List<dynamic>?)
          ?.map((e) => WorkSlots3.fromJson(e as Map<String, dynamic>))
          .toList(),
    );

Map<String, dynamic> _$SaturdayToJson(Saturday instance) => <String, dynamic>{
      'work_slots': instance.workSlots,
    };
