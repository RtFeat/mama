// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'entity_lure_history_total.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

EntityLureHistoryTotal _$EntityLureHistoryTotalFromJson(
        Map<String, dynamic> json) =>
    EntityLureHistoryTotal(
      pumpingLure: (json['pumping_lure'] as List<dynamic>?)
          ?.map((e) => EntityLureHistory.fromJson(e as Map<String, dynamic>))
          .toList(),
      object1: json["time_to_end_don't_use"] as String?,
      timeToEndTotal: json['time_to_end_total'] as String?,
    );

Map<String, dynamic> _$EntityLureHistoryTotalToJson(
        EntityLureHistoryTotal instance) =>
    <String, dynamic>{
      'pumping_lure': instance.pumpingLure,
      "time_to_end_don't_use": instance.object1,
      'time_to_end_total': instance.timeToEndTotal,
    };
