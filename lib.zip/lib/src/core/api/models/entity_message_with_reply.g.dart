// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'entity_message_with_reply.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

EntityMessageWithReply _$EntityMessageWithReplyFromJson(
        Map<String, dynamic> json) =>
    EntityMessageWithReply(
      chatId: json['chat_id'] as String?,
      createdAt: json['created_at'] as String?,
      files: (json['files'] as List<dynamic>?)
          ?.map((e) => EntityMessageDto.fromJson(e as Map<String, dynamic>))
          .toList(),
      id: json['id'] as String?,
      professionId: json['profession_id'] as String?,
      readAt: json['read_at'] as String?,
      senderAvatar: json['sender_avatar'] as String?,
      senderId: json['sender_id'] as String?,
      senderName: json['sender_name'] as String?,
      senderProfession: json['sender_profession'] as String?,
      senderSurname: json['sender_surname'] as String?,
      text: json['text'] as String?,
    );

Map<String, dynamic> _$EntityMessageWithReplyToJson(
        EntityMessageWithReply instance) =>
    <String, dynamic>{
      'chat_id': instance.chatId,
      'created_at': instance.createdAt,
      'files': instance.files,
      'id': instance.id,
      'profession_id': instance.professionId,
      'read_at': instance.readAt,
      'sender_avatar': instance.senderAvatar,
      'sender_id': instance.senderId,
      'sender_name': instance.senderName,
      'sender_profession': instance.senderProfession,
      'sender_surname': instance.senderSurname,
      'text': instance.text,
    };
