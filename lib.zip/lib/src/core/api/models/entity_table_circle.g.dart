// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'entity_table_circle.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

EntityTableCircle _$EntityTableCircleFromJson(Map<String, dynamic> json) =>
    EntityTableCircle(
      currentCircle: json['current_circle'] == null
          ? null
          : EntityCurrentCircle.fromJson(
              json['current_circle'] as Map<String, dynamic>),
      dynamicsCircle: json['dynamics_circle'] == null
          ? null
          : EntityDynamicsCircle.fromJson(
              json['dynamics_circle'] as Map<String, dynamic>),
      table: (json['table'] as List<dynamic>?)
          ?.map((e) =>
              EntityCurrentCircleStruct.fromJson(e as Map<String, dynamic>))
          .toList(),
    );

Map<String, dynamic> _$EntityTableCircleToJson(EntityTableCircle instance) =>
    <String, dynamic>{
      'current_circle': instance.currentCircle,
      'dynamics_circle': instance.dynamicsCircle,
      'table': instance.table,
    };
