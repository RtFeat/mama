// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'moderator_update_feedback_type_dto.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

ModeratorUpdateFeedbackTypeDto _$ModeratorUpdateFeedbackTypeDtoFromJson(
        Map<String, dynamic> json) =>
    ModeratorUpdateFeedbackTypeDto(
      id: json['id'] as String?,
      type: json['type'] as String?,
    );

Map<String, dynamic> _$ModeratorUpdateFeedbackTypeDtoToJson(
        ModeratorUpdateFeedbackTypeDto instance) =>
    <String, dynamic>{
      'id': instance.id,
      'type': instance.type,
    };
