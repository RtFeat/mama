// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'online_school_resp_online_school_numbers.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

OnlineSchoolRespOnlineSchoolNumbers
    _$OnlineSchoolRespOnlineSchoolNumbersFromJson(Map<String, dynamic> json) =>
        OnlineSchoolRespOnlineSchoolNumbers(
          list: (json['list'] as List<dynamic>?)
              ?.map((e) =>
                  EntityOnlineSchoolNumber.fromJson(e as Map<String, dynamic>))
              .toList(),
        );

Map<String, dynamic> _$OnlineSchoolRespOnlineSchoolNumbersToJson(
        OnlineSchoolRespOnlineSchoolNumbers instance) =>
    <String, dynamic>{
      'list': instance.list,
    };
