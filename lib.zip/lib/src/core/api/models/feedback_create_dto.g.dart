// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'feedback_create_dto.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

FeedbackCreateDto _$FeedbackCreateDtoFromJson(Map<String, dynamic> json) =>
    FeedbackCreateDto(
      text: json['text'] as String?,
    );

Map<String, dynamic> _$FeedbackCreateDtoToJson(FeedbackCreateDto instance) =>
    <String, dynamic>{
      'text': instance.text,
    };
