// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'article_get_article_for_you.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

ArticleGetArticleForYou _$ArticleGetArticleForYouFromJson(
        Map<String, dynamic> json) =>
    ArticleGetArticleForYou(
      list: (json['list'] as List<dynamic>?)
          ?.map(
              (e) => EntityArticleResponse.fromJson(e as Map<String, dynamic>))
          .toList(),
    );

Map<String, dynamic> _$ArticleGetArticleForYouToJson(
        ArticleGetArticleForYou instance) =>
    <String, dynamic>{
      'list': instance.list,
    };
