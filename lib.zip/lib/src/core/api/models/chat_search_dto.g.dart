// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'chat_search_dto.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

ChatSearchDto _$ChatSearchDtoFromJson(Map<String, dynamic> json) =>
    ChatSearchDto(
      chatId: json['chat_id'] as String?,
      typeOfChat: json['type_of_chat'] as String?,
    );

Map<String, dynamic> _$ChatSearchDtoToJson(ChatSearchDto instance) =>
    <String, dynamic>{
      'chat_id': instance.chatId,
      'type_of_chat': instance.typeOfChat,
    };
