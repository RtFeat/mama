// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'entity_dynamics_height.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

EntityDynamicsHeight _$EntityDynamicsHeightFromJson(
        Map<String, dynamic> json) =>
    EntityDynamicsHeight(
      days: json['days'] as String?,
      heightGain: json['height_gain'] as String?,
      heightToDay: json['height_to_day'] as String?,
      timeDuration: json['time_duration'] as String?,
    );

Map<String, dynamic> _$EntityDynamicsHeightToJson(
        EntityDynamicsHeight instance) =>
    <String, dynamic>{
      'days': instance.days,
      'height_gain': instance.heightGain,
      'height_to_day': instance.heightToDay,
      'time_duration': instance.timeDuration,
    };
