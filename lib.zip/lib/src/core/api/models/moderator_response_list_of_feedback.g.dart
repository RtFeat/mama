// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'moderator_response_list_of_feedback.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

ModeratorResponseListOfFeedback _$ModeratorResponseListOfFeedbackFromJson(
        Map<String, dynamic> json) =>
    ModeratorResponseListOfFeedback(
      feedback: (json['feedback'] as List<dynamic>?)
          ?.map((e) => EntityFeedback.fromJson(e as Map<String, dynamic>))
          .toList(),
    );

Map<String, dynamic> _$ModeratorResponseListOfFeedbackToJson(
        ModeratorResponseListOfFeedback instance) =>
    <String, dynamic>{
      'feedback': instance.feedback,
    };
