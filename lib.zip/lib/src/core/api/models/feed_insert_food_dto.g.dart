// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'feed_insert_food_dto.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

FeedInsertFoodDto _$FeedInsertFoodDtoFromJson(Map<String, dynamic> json) =>
    FeedInsertFoodDto(
      chest: (json['chest'] as num?)?.toInt(),
      childId: json['child_id'] as String?,
      mixture: (json['mixture'] as num?)?.toInt(),
      notes: json['notes'] as String?,
      timeToEnd: json['time_to_end'] as String?,
    );

Map<String, dynamic> _$FeedInsertFoodDtoToJson(FeedInsertFoodDto instance) =>
    <String, dynamic>{
      'chest': instance.chest,
      'child_id': instance.childId,
      'mixture': instance.mixture,
      'notes': instance.notes,
      'time_to_end': instance.timeToEnd,
    };
