// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'entity_user_response.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

EntityUserResponse _$EntityUserResponseFromJson(Map<String, dynamic> json) =>
    EntityUserResponse(
      account: json['account'] == null
          ? null
          : EntityAccount.fromJson(json['account'] as Map<String, dynamic>),
      childs: (json['childs'] as List<dynamic>?)
          ?.map((e) => EntityChild.fromJson(e as Map<String, dynamic>))
          .toList(),
      user: json['user'] == null
          ? null
          : EntityBaseUser.fromJson(json['user'] as Map<String, dynamic>),
    );

Map<String, dynamic> _$EntityUserResponseToJson(EntityUserResponse instance) =>
    <String, dynamic>{
      'account': instance.account,
      'childs': instance.childs,
      'user': instance.user,
    };
