// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'entity_work_slot.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

EntityWorkSlot _$EntityWorkSlotFromJson(Map<String, dynamic> json) =>
    EntityWorkSlot(
      workSlot: json['work_slot'] as String?,
    );

Map<String, dynamic> _$EntityWorkSlotToJson(EntityWorkSlot instance) =>
    <String, dynamic>{
      'work_slot': instance.workSlot,
    };
