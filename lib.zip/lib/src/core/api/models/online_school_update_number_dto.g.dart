// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'online_school_update_number_dto.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

OnlineSchoolUpdateNumberDto _$OnlineSchoolUpdateNumberDtoFromJson(
        Map<String, dynamic> json) =>
    OnlineSchoolUpdateNumberDto(
      numberNew: json['number_new'] as String?,
      numberOld: json['number_old'] as String?,
      onlineSchoolId: json['online_school_id'] as String?,
    );

Map<String, dynamic> _$OnlineSchoolUpdateNumberDtoToJson(
        OnlineSchoolUpdateNumberDto instance) =>
    <String, dynamic>{
      'number_new': instance.numberNew,
      'number_old': instance.numberOld,
      'online_school_id': instance.onlineSchoolId,
    };
