// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'article_update_status.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

ArticleUpdateStatus _$ArticleUpdateStatusFromJson(Map<String, dynamic> json) =>
    ArticleUpdateStatus(
      id: json['id'] as String?,
      status: json['status'] as String?,
    );

Map<String, dynamic> _$ArticleUpdateStatusToJson(
        ArticleUpdateStatus instance) =>
    <String, dynamic>{
      'id': instance.id,
      'status': instance.status,
    };
