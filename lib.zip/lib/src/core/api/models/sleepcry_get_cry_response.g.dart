// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'sleepcry_get_cry_response.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

SleepcryGetCryResponse _$SleepcryGetCryResponseFromJson(
        Map<String, dynamic> json) =>
    SleepcryGetCryResponse(
      list: (json['list'] as List<dynamic>?)
          ?.map((e) => EntityCry.fromJson(e as Map<String, dynamic>))
          .toList(),
    );

Map<String, dynamic> _$SleepcryGetCryResponseToJson(
        SleepcryGetCryResponse instance) =>
    <String, dynamic>{
      'list': instance.list,
    };
