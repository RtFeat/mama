// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'chat_response_get_all_specialists_in_chats.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

ChatResponseGetAllSpecialistsInChats
    _$ChatResponseGetAllSpecialistsInChatsFromJson(Map<String, dynamic> json) =>
        ChatResponseGetAllSpecialistsInChats(
          specialists: (json['specialists'] as List<dynamic>?)
              ?.map((e) => EntityAccountMe.fromJson(e as Map<String, dynamic>))
              .toList(),
        );

Map<String, dynamic> _$ChatResponseGetAllSpecialistsInChatsToJson(
        ChatResponseGetAllSpecialistsInChats instance) =>
    <String, dynamic>{
      'specialists': instance.specialists,
    };
