// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'entity_country.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

EntityCountry _$EntityCountryFromJson(Map<String, dynamic> json) =>
    EntityCountry(
      id: (json['id'] as num?)?.toInt(),
      name: json['name'] as String?,
    );

Map<String, dynamic> _$EntityCountryToJson(EntityCountry instance) =>
    <String, dynamic>{
      'id': instance.id,
      'name': instance.name,
    };
