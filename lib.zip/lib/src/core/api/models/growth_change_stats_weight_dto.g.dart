// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'growth_change_stats_weight_dto.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

GrowthChangeStatsWeightDto _$GrowthChangeStatsWeightDtoFromJson(
        Map<String, dynamic> json) =>
    GrowthChangeStatsWeightDto(
      stats: json['stats'] == null
          ? null
          : EntityWeight.fromJson(json['stats'] as Map<String, dynamic>),
    );

Map<String, dynamic> _$GrowthChangeStatsWeightDtoToJson(
        GrowthChangeStatsWeightDto instance) =>
    <String, dynamic>{
      'stats': instance.stats,
    };
