// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'entity_get_height.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

EntityGetHeight _$EntityGetHeightFromJson(Map<String, dynamic> json) =>
    EntityGetHeight(
      getHeights: json['get_heights'] as String?,
      isNormal: json['is_normal'] as String?,
      median: json['median'] as String?,
      normal: json['normal'] as String?,
      notes: json['notes'] as String?,
      weeks: json['weeks'] as String?,
      weight: json['weight'] as String?,
    );

Map<String, dynamic> _$EntityGetHeightToJson(EntityGetHeight instance) =>
    <String, dynamic>{
      'get_heights': instance.getHeights,
      'is_normal': instance.isNormal,
      'median': instance.median,
      'normal': instance.normal,
      'notes': instance.notes,
      'weeks': instance.weeks,
      'weight': instance.weight,
    };
