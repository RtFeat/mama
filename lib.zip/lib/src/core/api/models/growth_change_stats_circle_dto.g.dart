// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'growth_change_stats_circle_dto.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

GrowthChangeStatsCircleDto _$GrowthChangeStatsCircleDtoFromJson(
        Map<String, dynamic> json) =>
    GrowthChangeStatsCircleDto(
      stats: json['stats'] == null
          ? null
          : EntityCircle.fromJson(json['stats'] as Map<String, dynamic>),
    );

Map<String, dynamic> _$GrowthChangeStatsCircleDtoToJson(
        GrowthChangeStatsCircleDto instance) =>
    <String, dynamic>{
      'stats': instance.stats,
    };
