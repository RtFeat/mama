// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'growth_response_history_weight.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

GrowthResponseHistoryWeight _$GrowthResponseHistoryWeightFromJson(
        Map<String, dynamic> json) =>
    GrowthResponseHistoryWeight(
      list: (json['list'] as List<dynamic>?)
          ?.map((e) => EntityHistoryWeight.fromJson(e as Map<String, dynamic>))
          .toList(),
    );

Map<String, dynamic> _$GrowthResponseHistoryWeightToJson(
        GrowthResponseHistoryWeight instance) =>
    <String, dynamic>{
      'list': instance.list,
    };
