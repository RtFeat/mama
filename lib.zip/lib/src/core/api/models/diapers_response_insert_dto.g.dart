// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'diapers_response_insert_dto.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

DiapersResponseInsertDto _$DiapersResponseInsertDtoFromJson(
        Map<String, dynamic> json) =>
    DiapersResponseInsertDto(
      id: json['id'] as String?,
    );

Map<String, dynamic> _$DiapersResponseInsertDtoToJson(
        DiapersResponseInsertDto instance) =>
    <String, dynamic>{
      'id': instance.id,
    };
