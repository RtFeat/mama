// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'moderator_send_admin_notification_dto.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

ModeratorSendAdminNotificationDto _$ModeratorSendAdminNotificationDtoFromJson(
        Map<String, dynamic> json) =>
    ModeratorSendAdminNotificationDto(
      text: json['text'] as String?,
      userId: json['user_id'] as String?,
    );

Map<String, dynamic> _$ModeratorSendAdminNotificationDtoToJson(
        ModeratorSendAdminNotificationDto instance) =>
    <String, dynamic>{
      'text': instance.text,
      'user_id': instance.userId,
    };
