// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'article_article_writer.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

ArticleArticleWriter _$ArticleArticleWriterFromJson(
        Map<String, dynamic> json) =>
    ArticleArticleWriter(
      counter: (json['counter'] as num?)?.toInt(),
      writer: json['writer'] == null
          ? null
          : EntityArticleWriter.fromJson(
              json['writer'] as Map<String, dynamic>),
    );

Map<String, dynamic> _$ArticleArticleWriterToJson(
        ArticleArticleWriter instance) =>
    <String, dynamic>{
      'counter': instance.counter,
      'writer': instance.writer,
    };
