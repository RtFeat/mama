// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'entity_current_wight.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

EntityCurrentWight _$EntityCurrentWightFromJson(Map<String, dynamic> json) =>
    EntityCurrentWight(
      data: json['data'] as String?,
      days: json['days'] as String?,
      normal: json['normal'] as String?,
      weight: json['weight'] as String?,
    );

Map<String, dynamic> _$EntityCurrentWightToJson(EntityCurrentWight instance) =>
    <String, dynamic>{
      'data': instance.data,
      'days': instance.days,
      'normal': instance.normal,
      'weight': instance.weight,
    };
