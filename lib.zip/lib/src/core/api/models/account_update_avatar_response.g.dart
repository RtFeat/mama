// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'account_update_avatar_response.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

AccountUpdateAvatarResponse _$AccountUpdateAvatarResponseFromJson(
        Map<String, dynamic> json) =>
    AccountUpdateAvatarResponse(
      avatar: json['avatar'] as String?,
    );

Map<String, dynamic> _$AccountUpdateAvatarResponseToJson(
        AccountUpdateAvatarResponse instance) =>
    <String, dynamic>{
      'avatar': instance.avatar,
    };
