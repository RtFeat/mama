// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'diapers_delete_diaper.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

DiapersDeleteDiaper _$DiapersDeleteDiaperFromJson(Map<String, dynamic> json) =>
    DiapersDeleteDiaper(
      id: json['id'] as String,
    );

Map<String, dynamic> _$DiapersDeleteDiaperToJson(
        DiapersDeleteDiaper instance) =>
    <String, dynamic>{
      'id': instance.id,
    };
