// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'sleepcry_response_insert_dto.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

SleepcryResponseInsertDto _$SleepcryResponseInsertDtoFromJson(
        Map<String, dynamic> json) =>
    SleepcryResponseInsertDto(
      id: json['id'] as String?,
    );

Map<String, dynamic> _$SleepcryResponseInsertDtoToJson(
        SleepcryResponseInsertDto instance) =>
    <String, dynamic>{
      'id': instance.id,
    };
