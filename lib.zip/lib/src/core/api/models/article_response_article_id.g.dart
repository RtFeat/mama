// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'article_response_article_id.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

ArticleResponseArticleID _$ArticleResponseArticleIDFromJson(
        Map<String, dynamic> json) =>
    ArticleResponseArticleID(
      id: json['id'] as String?,
    );

Map<String, dynamic> _$ArticleResponseArticleIDToJson(
        ArticleResponseArticleID instance) =>
    <String, dynamic>{
      'id': instance.id,
    };
