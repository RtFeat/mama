// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'feed_response_history_chest.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

FeedResponseHistoryChest _$FeedResponseHistoryChestFromJson(
        Map<String, dynamic> json) =>
    FeedResponseHistoryChest(
      list: (json['list'] as List<dynamic>?)
          ?.map((e) =>
              EntityChestHistoryTotal.fromJson(e as Map<String, dynamic>))
          .toList(),
    );

Map<String, dynamic> _$FeedResponseHistoryChestToJson(
        FeedResponseHistoryChest instance) =>
    <String, dynamic>{
      'list': instance.list,
    };
