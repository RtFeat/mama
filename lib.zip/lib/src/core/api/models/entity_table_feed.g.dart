// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'entity_table_feed.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

EntityTableFeed _$EntityTableFeedFromJson(Map<String, dynamic> json) =>
    EntityTableFeed(
      chest: json['chest'] as String?,
      food: json['food'] as String?,
      lure: json['lure'] as String?,
      notes: json['notes'] as String?,
      time: json['time'] as String?,
    );

Map<String, dynamic> _$EntityTableFeedToJson(EntityTableFeed instance) =>
    <String, dynamic>{
      'chest': instance.chest,
      'food': instance.food,
      'lure': instance.lure,
      'notes': instance.notes,
      'time': instance.time,
    };
