// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'feed_delete_chest_notes_dto.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

FeedDeleteChestNotesDto _$FeedDeleteChestNotesDtoFromJson(
        Map<String, dynamic> json) =>
    FeedDeleteChestNotesDto(
      id: json['id'] as String,
    );

Map<String, dynamic> _$FeedDeleteChestNotesDtoToJson(
        FeedDeleteChestNotesDto instance) =>
    <String, dynamic>{
      'id': instance.id,
    };
