// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'chat_chat_response.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

ChatChatResponse _$ChatChatResponseFromJson(Map<String, dynamic> json) =>
    ChatChatResponse(
      chat: json['chat'] == null
          ? null
          : EntitySingleChat.fromJson(json['chat'] as Map<String, dynamic>),
    );

Map<String, dynamic> _$ChatChatResponseToJson(ChatChatResponse instance) =>
    <String, dynamic>{
      'chat': instance.chat,
    };
