// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'moderator_delete_dto.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

ModeratorDeleteDto _$ModeratorDeleteDtoFromJson(Map<String, dynamic> json) =>
    ModeratorDeleteDto(
      id: json['id'] as String?,
    );

Map<String, dynamic> _$ModeratorDeleteDtoToJson(ModeratorDeleteDto instance) =>
    <String, dynamic>{
      'id': instance.id,
    };
