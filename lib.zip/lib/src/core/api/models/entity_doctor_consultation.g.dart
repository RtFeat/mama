// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'entity_doctor_consultation.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

EntityDoctorConsultation _$EntityDoctorConsultationFromJson(
        Map<String, dynamic> json) =>
    EntityDoctorConsultation(
      accountId: json['account_id'] as String?,
      avatar: json['avatar'] as String?,
      createdAt: json['created_at'] as String?,
      firstName: json['first_name'] as String?,
      id: json['id'] as String?,
      isConsultation: json['is_consultation'] as bool?,
      lastName: json['last_name'] as String?,
      profession: json['profession'] as String?,
      updatedAt: json['updated_at'] as String?,
    );

Map<String, dynamic> _$EntityDoctorConsultationToJson(
        EntityDoctorConsultation instance) =>
    <String, dynamic>{
      'account_id': instance.accountId,
      'avatar': instance.avatar,
      'created_at': instance.createdAt,
      'first_name': instance.firstName,
      'id': instance.id,
      'is_consultation': instance.isConsultation,
      'last_name': instance.lastName,
      'profession': instance.profession,
      'updated_at': instance.updatedAt,
    };
