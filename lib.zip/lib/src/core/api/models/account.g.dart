// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'account.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

Account _$AccountFromJson(Map<String, dynamic> json) => Account(
      firstName: json['first_name'] as String,
      phone: json['phone'] as String,
      secondName: json['second_name'] as String,
      fcmToken: json['fcm_token'] as String?,
      gender: json['gender'] == null
          ? null
          : EntityGender.fromJson(json['gender'] as String),
      lastName: json['last_name'] as String?,
    );

Map<String, dynamic> _$AccountToJson(Account instance) => <String, dynamic>{
      'fcm_token': instance.fcmToken,
      'first_name': instance.firstName,
      'gender': _$EntityGenderEnumMap[instance.gender],
      'last_name': instance.lastName,
      'phone': instance.phone,
      'second_name': instance.secondName,
    };

const _$EntityGenderEnumMap = {
  EntityGender.male: 'MALE',
  EntityGender.female: 'FEMALE',
  EntityGender.$unknown: r'$unknown',
};
