// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'entity_table_sleep_cry_total.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

EntityTableSleepCryTotal _$EntityTableSleepCryTotalFromJson(
        Map<String, dynamic> json) =>
    EntityTableSleepCryTotal(
      cry: json['cry'] as String?,
      notes: json['notes'] as String?,
      sleep: json['sleep'] as String?,
      time: json['time'] as String?,
    );

Map<String, dynamic> _$EntityTableSleepCryTotalToJson(
        EntityTableSleepCryTotal instance) =>
    <String, dynamic>{
      'cry': instance.cry,
      'notes': instance.notes,
      'sleep': instance.sleep,
      'time': instance.time,
    };
