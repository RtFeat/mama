// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'entity_account_me.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

EntityAccountMe _$EntityAccountMeFromJson(Map<String, dynamic> json) =>
    EntityAccountMe(
      account: json['account'] == null
          ? null
          : EntityAccount.fromJson(json['account'] as Map<String, dynamic>),
      doctor: json['doctor'] == null
          ? null
          : EntityDoctorBase.fromJson(json['doctor'] as Map<String, dynamic>),
      onlineSchool: json['online_school'] == null
          ? null
          : EntityOnlineSchool.fromJson(
              json['online_school'] as Map<String, dynamic>),
    );

Map<String, dynamic> _$EntityAccountMeToJson(EntityAccountMe instance) =>
    <String, dynamic>{
      'account': instance.account,
      'doctor': instance.doctor,
      'online_school': instance.onlineSchool,
    };
