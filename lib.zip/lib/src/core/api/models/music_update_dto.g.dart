// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'music_update_dto.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

MusicUpdateDto _$MusicUpdateDtoFromJson(Map<String, dynamic> json) =>
    MusicUpdateDto(
      musicId: json['music_id'] as String?,
      status: json['status'] as String?,
    );

Map<String, dynamic> _$MusicUpdateDtoToJson(MusicUpdateDto instance) =>
    <String, dynamic>{
      'music_id': instance.musicId,
      'status': instance.status,
    };
