// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'auth_sign_up_response.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

AuthSignUpResponse _$AuthSignUpResponseFromJson(Map<String, dynamic> json) =>
    AuthSignUpResponse(
      accessToken: json['access_token'] as String?,
      account: json['account'] == null
          ? null
          : EntityUserResponse.fromJson(
              json['account'] as Map<String, dynamic>),
      chat: json['chat'] == null
          ? null
          : EntitySingleChat.fromJson(json['chat'] as Map<String, dynamic>),
      role: json['role'] == null
          ? null
          : EntityRole.fromJson(json['role'] as String),
      status: json['status'] == null
          ? null
          : EntityStatus.fromJson(json['status'] as String),
    );

Map<String, dynamic> _$AuthSignUpResponseToJson(AuthSignUpResponse instance) =>
    <String, dynamic>{
      'access_token': instance.accessToken,
      'account': instance.account,
      'chat': instance.chat,
      'role': _$EntityRoleEnumMap[instance.role],
      'status': _$EntityStatusEnumMap[instance.status],
    };

const _$EntityRoleEnumMap = {
  EntityRole.admin: 'ADMIN',
  EntityRole.moderator: 'MODERATOR',
  EntityRole.doctor: 'DOCTOR',
  EntityRole.user: 'USER',
  EntityRole.onlineSchool: 'ONLINE_SCHOOL',
  EntityRole.$unknown: r'$unknown',
};

const _$EntityStatusEnumMap = {
  EntityStatus.subscribed: 'SUBSCRIBED',
  EntityStatus.promoCode: 'PROMO_CODE',
  EntityStatus.trial: 'TRIAL',
  EntityStatus.nOSubscribed: 'NO_SUBSCRIBED',
  EntityStatus.deleted: 'DELETED',
  EntityStatus.$unknown: r'$unknown',
};
