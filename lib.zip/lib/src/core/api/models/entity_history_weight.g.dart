// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'entity_history_weight.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

EntityHistoryWeight _$EntityHistoryWeightFromJson(Map<String, dynamic> json) =>
    EntityHistoryWeight(
      allData: json['all_data'] as String?,
      data: json['data'] as String?,
      id: json['id'] as String?,
      normal: json['normal'] as String?,
      notes: json['notes'] as String?,
      weeks: json['weeks'] as String?,
      weight: json['weight'] as String?,
    );

Map<String, dynamic> _$EntityHistoryWeightToJson(
        EntityHistoryWeight instance) =>
    <String, dynamic>{
      'all_data': instance.allData,
      'data': instance.data,
      'id': instance.id,
      'normal': instance.normal,
      'notes': instance.notes,
      'weeks': instance.weeks,
      'weight': instance.weight,
    };
