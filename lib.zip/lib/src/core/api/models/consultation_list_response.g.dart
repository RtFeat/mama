// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'consultation_list_response.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

ConsultationListResponse _$ConsultationListResponseFromJson(
        Map<String, dynamic> json) =>
    ConsultationListResponse(
      consultations: (json['consultations'] as List<dynamic>?)
          ?.map((e) =>
              EntityConsultationResponse.fromJson(e as Map<String, dynamic>))
          .toList(),
    );

Map<String, dynamic> _$ConsultationListResponseToJson(
        ConsultationListResponse instance) =>
    <String, dynamic>{
      'consultations': instance.consultations,
    };
