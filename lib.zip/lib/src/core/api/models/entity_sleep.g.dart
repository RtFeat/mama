// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'entity_sleep.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

EntitySleep _$EntitySleepFromJson(Map<String, dynamic> json) => EntitySleep(
      allSleep: json['all_sleep'] as String?,
      childId: json['child_id'] as String?,
      id: json['id'] as String?,
      notes: json['notes'] as String?,
      timeEnd: json['time_end'] as String?,
      timeToEnd: json['time_to_end'] as String?,
      timeToStart: json['time_to_start'] as String?,
    );

Map<String, dynamic> _$EntitySleepToJson(EntitySleep instance) =>
    <String, dynamic>{
      'all_sleep': instance.allSleep,
      'child_id': instance.childId,
      'id': instance.id,
      'notes': instance.notes,
      'time_end': instance.timeEnd,
      'time_to_end': instance.timeToEnd,
      'time_to_start': instance.timeToStart,
    };
