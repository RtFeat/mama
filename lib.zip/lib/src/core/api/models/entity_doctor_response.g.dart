// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'entity_doctor_response.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

EntityDoctorResponse _$EntityDoctorResponseFromJson(
        Map<String, dynamic> json) =>
    EntityDoctorResponse(
      account: json['account'] == null
          ? null
          : EntityAccount.fromJson(json['account'] as Map<String, dynamic>),
      countArticles: (json['count_articles'] as num?)?.toInt(),
      createdAt: json['created_at'] as String?,
      id: json['id'] as String?,
      isConsultation: json['is_consultation'] as bool?,
      profession: json['profession'] as String?,
      timeWork: json['time_work'] == null
          ? null
          : EntityDoctorWorkTimeResponse.fromJson(
              json['time_work'] as Map<String, dynamic>),
      updatedAt: json['updated_at'] as String?,
    );

Map<String, dynamic> _$EntityDoctorResponseToJson(
        EntityDoctorResponse instance) =>
    <String, dynamic>{
      'account': instance.account,
      'count_articles': instance.countArticles,
      'created_at': instance.createdAt,
      'id': instance.id,
      'is_consultation': instance.isConsultation,
      'profession': instance.profession,
      'time_work': instance.timeWork,
      'updated_at': instance.updatedAt,
    };
