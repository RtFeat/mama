// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'feedback_response_create.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

FeedbackResponseCreate _$FeedbackResponseCreateFromJson(
        Map<String, dynamic> json) =>
    FeedbackResponseCreate(
      id: json['id'] as String?,
    );

Map<String, dynamic> _$FeedbackResponseCreateToJson(
        FeedbackResponseCreate instance) =>
    <String, dynamic>{
      'id': instance.id,
    };
