// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'chat_response_get_all_users_in_chats.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

ChatResponseGetAllUsersInChats _$ChatResponseGetAllUsersInChatsFromJson(
        Map<String, dynamic> json) =>
    ChatResponseGetAllUsersInChats(
      users: (json['users'] as List<dynamic>?)
          ?.map((e) => EntityAccount.fromJson(e as Map<String, dynamic>))
          .toList(),
    );

Map<String, dynamic> _$ChatResponseGetAllUsersInChatsToJson(
        ChatResponseGetAllUsersInChats instance) =>
    <String, dynamic>{
      'users': instance.users,
    };
