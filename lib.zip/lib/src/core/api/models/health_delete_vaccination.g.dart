// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'health_delete_vaccination.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

HealthDeleteVaccination _$HealthDeleteVaccinationFromJson(
        Map<String, dynamic> json) =>
    HealthDeleteVaccination(
      id: json['id'] as String,
    );

Map<String, dynamic> _$HealthDeleteVaccinationToJson(
        HealthDeleteVaccination instance) =>
    <String, dynamic>{
      'id': instance.id,
    };
