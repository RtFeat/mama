// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'consultation_set_dto.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

ConsultationSetDto _$ConsultationSetDtoFromJson(Map<String, dynamic> json) =>
    ConsultationSetDto(
      comment: json['comment'] as String?,
      day: json['day'] as String?,
      doctorId: json['doctor_id'] as String?,
      slot: json['slot'] as String?,
      timeWeek: json['time_week'] as String?,
      type: json['type'] as String?,
      userId: json['user_id'] as String?,
    );

Map<String, dynamic> _$ConsultationSetDtoToJson(ConsultationSetDto instance) =>
    <String, dynamic>{
      'comment': instance.comment,
      'day': instance.day,
      'doctor_id': instance.doctorId,
      'slot': instance.slot,
      'time_week': instance.timeWeek,
      'type': instance.type,
      'user_id': instance.userId,
    };
