// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'sleepcry_delete_sleep_dto.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

SleepcryDeleteSleepDto _$SleepcryDeleteSleepDtoFromJson(
        Map<String, dynamic> json) =>
    SleepcryDeleteSleepDto(
      id: json['id'] as String?,
    );

Map<String, dynamic> _$SleepcryDeleteSleepDtoToJson(
        SleepcryDeleteSleepDto instance) =>
    <String, dynamic>{
      'id': instance.id,
    };
