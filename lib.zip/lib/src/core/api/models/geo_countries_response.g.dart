// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'geo_countries_response.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

GeoCountriesResponse _$GeoCountriesResponseFromJson(
        Map<String, dynamic> json) =>
    GeoCountriesResponse(
      countries: (json['countries'] as List<dynamic>?)
          ?.map((e) => EntityCountry.fromJson(e as Map<String, dynamic>))
          .toList(),
    );

Map<String, dynamic> _$GeoCountriesResponseToJson(
        GeoCountriesResponse instance) =>
    <String, dynamic>{
      'countries': instance.countries,
    };
