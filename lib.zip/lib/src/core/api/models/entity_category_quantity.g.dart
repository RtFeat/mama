// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'entity_category_quantity.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

EntityCategoryQuantity _$EntityCategoryQuantityFromJson(
        Map<String, dynamic> json) =>
    EntityCategoryQuantity(
      id: json['id'] as String?,
      name: json['name'] as String?,
      quantity: (json['quantity'] as num?)?.toInt(),
    );

Map<String, dynamic> _$EntityCategoryQuantityToJson(
        EntityCategoryQuantity instance) =>
    <String, dynamic>{
      'id': instance.id,
      'name': instance.name,
      'quantity': instance.quantity,
    };
