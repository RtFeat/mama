// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'health_completed_drug.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

HealthCompletedDrug _$HealthCompletedDrugFromJson(Map<String, dynamic> json) =>
    HealthCompletedDrug(
      drugId: json['drug_id'] as String?,
    );

Map<String, dynamic> _$HealthCompletedDrugToJson(
        HealthCompletedDrug instance) =>
    <String, dynamic>{
      'drug_id': instance.drugId,
    };
