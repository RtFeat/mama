// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'entity_cry_history_total.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

EntityCryHistoryTotal _$EntityCryHistoryTotalFromJson(
        Map<String, dynamic> json) =>
    EntityCryHistoryTotal(
      cryTotal: (json['Cry_total'] as List<dynamic>?)
          ?.map((e) => EntityCryHistory.fromJson(e as Map<String, dynamic>))
          .toList(),
      months: json['months'] as String?,
      time: json['time'] as String?,
      timeToEndTotal: json['time_to_end_total'] as String?,
    );

Map<String, dynamic> _$EntityCryHistoryTotalToJson(
        EntityCryHistoryTotal instance) =>
    <String, dynamic>{
      'Cry_total': instance.cryTotal,
      'months': instance.months,
      'time': instance.time,
      'time_to_end_total': instance.timeToEndTotal,
    };
