// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'article_response_photo.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

ArticleResponsePhoto _$ArticleResponsePhotoFromJson(
        Map<String, dynamic> json) =>
    ArticleResponsePhoto(
      filename: json['filename'] as String?,
    );

Map<String, dynamic> _$ArticleResponsePhotoToJson(
        ArticleResponsePhoto instance) =>
    <String, dynamic>{
      'filename': instance.filename,
    };
