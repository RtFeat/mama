// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'feed_response_history_lure.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

FeedResponseHistoryLure _$FeedResponseHistoryLureFromJson(
        Map<String, dynamic> json) =>
    FeedResponseHistoryLure(
      list: (json['list'] as List<dynamic>?)
          ?.map(
              (e) => EntityLureHistoryTotal.fromJson(e as Map<String, dynamic>))
          .toList(),
    );

Map<String, dynamic> _$FeedResponseHistoryLureToJson(
        FeedResponseHistoryLure instance) =>
    <String, dynamic>{
      'list': instance.list,
    };
