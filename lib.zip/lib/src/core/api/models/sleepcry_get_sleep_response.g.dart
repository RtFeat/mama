// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'sleepcry_get_sleep_response.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

SleepcryGetSleepResponse _$SleepcryGetSleepResponseFromJson(
        Map<String, dynamic> json) =>
    SleepcryGetSleepResponse(
      list: (json['list'] as List<dynamic>?)
          ?.map((e) => EntitySleep.fromJson(e as Map<String, dynamic>))
          .toList(),
    );

Map<String, dynamic> _$SleepcryGetSleepResponseToJson(
        SleepcryGetSleepResponse instance) =>
    <String, dynamic>{
      'list': instance.list,
    };
