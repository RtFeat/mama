// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'growth_get_height_response.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

GrowthGetHeightResponse _$GrowthGetHeightResponseFromJson(
        Map<String, dynamic> json) =>
    GrowthGetHeightResponse(
      list: json['list'] == null
          ? null
          : EntityTableHeight.fromJson(json['list'] as Map<String, dynamic>),
    );

Map<String, dynamic> _$GrowthGetHeightResponseToJson(
        GrowthGetHeightResponse instance) =>
    <String, dynamic>{
      'list': instance.list,
    };
