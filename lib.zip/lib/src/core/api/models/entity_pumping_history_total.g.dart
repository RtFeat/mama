// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'entity_pumping_history_total.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

EntityPumpingHistoryTotal _$EntityPumpingHistoryTotalFromJson(
        Map<String, dynamic> json) =>
    EntityPumpingHistoryTotal(
      pumpingHistory: (json['pumping_history'] as List<dynamic>?)
          ?.map((e) => EntityPumpingHistory.fromJson(e as Map<String, dynamic>))
          .toList(),
      timeToEnd: json['time_to_end'] as String?,
      timeToEndTotal: json['time_to_end_total'] as String?,
      totalLeft: (json['total_left'] as num?)?.toInt(),
      totalRight: (json['total_right'] as num?)?.toInt(),
      totalTotal: (json['total_total'] as num?)?.toInt(),
    );

Map<String, dynamic> _$EntityPumpingHistoryTotalToJson(
        EntityPumpingHistoryTotal instance) =>
    <String, dynamic>{
      'pumping_history': instance.pumpingHistory,
      'time_to_end': instance.timeToEnd,
      'time_to_end_total': instance.timeToEndTotal,
      'total_left': instance.totalLeft,
      'total_right': instance.totalRight,
      'total_total': instance.totalTotal,
    };
