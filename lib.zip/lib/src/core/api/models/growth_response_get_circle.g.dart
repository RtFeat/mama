// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'growth_response_get_circle.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

GrowthResponseGetCircle _$GrowthResponseGetCircleFromJson(
        Map<String, dynamic> json) =>
    GrowthResponseGetCircle(
      list: json['list'] == null
          ? null
          : EntityGetCircle.fromJson(json['list'] as Map<String, dynamic>),
    );

Map<String, dynamic> _$GrowthResponseGetCircleToJson(
        GrowthResponseGetCircle instance) =>
    <String, dynamic>{
      'list': instance.list,
    };
