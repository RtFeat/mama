// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'entity_online_school.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

EntityOnlineSchool _$EntityOnlineSchoolFromJson(Map<String, dynamic> json) =>
    EntityOnlineSchool(
      account: json['account'] as String?,
      createdAt: json['created_at'] as String?,
      id: json['id'] as String?,
      name: json['name'] as String?,
      updatedAt: json['updated_at'] as String?,
    );

Map<String, dynamic> _$EntityOnlineSchoolToJson(EntityOnlineSchool instance) =>
    <String, dynamic>{
      'account': instance.account,
      'created_at': instance.createdAt,
      'id': instance.id,
      'name': instance.name,
      'updated_at': instance.updatedAt,
    };
