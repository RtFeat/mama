// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'moderator_stat_resp.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

ModeratorStatResp _$ModeratorStatRespFromJson(Map<String, dynamic> json) =>
    ModeratorStatResp(
      list: (json['list'] as List<dynamic>?)
          ?.map((e) => EntityStatAccountBuy.fromJson(e as Map<String, dynamic>))
          .toList(),
    );

Map<String, dynamic> _$ModeratorStatRespToJson(ModeratorStatResp instance) =>
    <String, dynamic>{
      'list': instance.list,
    };
