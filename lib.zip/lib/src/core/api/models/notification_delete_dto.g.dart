// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'notification_delete_dto.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

NotificationDeleteDto _$NotificationDeleteDtoFromJson(
        Map<String, dynamic> json) =>
    NotificationDeleteDto(
      id: json['id'] as String?,
    );

Map<String, dynamic> _$NotificationDeleteDtoToJson(
        NotificationDeleteDto instance) =>
    <String, dynamic>{
      'id': instance.id,
    };
