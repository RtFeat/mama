// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'entity_consultation_response.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

EntityConsultationResponse _$EntityConsultationResponseFromJson(
        Map<String, dynamic> json) =>
    EntityConsultationResponse(
      account: json['account'] == null
          ? null
          : EntityAccount.fromJson(json['account'] as Map<String, dynamic>),
      comment: json['comment'] as String?,
      createdAt: json['created_at'] as String?,
      doctor: json['doctor'] == null
          ? null
          : EntityDoctorConsultation.fromJson(
              json['doctor'] as Map<String, dynamic>),
      id: json['id'] as String?,
      status: json['status'] as String?,
      timeBegin: json['time_begin'] as String?,
      timeEnd: json['time_end'] as String?,
      type: json['type'] as String?,
    );

Map<String, dynamic> _$EntityConsultationResponseToJson(
        EntityConsultationResponse instance) =>
    <String, dynamic>{
      'account': instance.account,
      'comment': instance.comment,
      'created_at': instance.createdAt,
      'doctor': instance.doctor,
      'id': instance.id,
      'status': instance.status,
      'time_begin': instance.timeBegin,
      'time_end': instance.timeEnd,
      'type': instance.type,
    };
