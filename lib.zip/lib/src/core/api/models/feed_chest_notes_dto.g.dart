// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'feed_chest_notes_dto.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

FeedChestNotesDto _$FeedChestNotesDtoFromJson(Map<String, dynamic> json) =>
    FeedChestNotesDto(
      id: json['id'] as String,
      notes: json['notes'] as String,
    );

Map<String, dynamic> _$FeedChestNotesDtoToJson(FeedChestNotesDto instance) =>
    <String, dynamic>{
      'id': instance.id,
      'notes': instance.notes,
    };
