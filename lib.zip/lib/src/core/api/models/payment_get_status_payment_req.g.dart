// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'payment_get_status_payment_req.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

PaymentGetStatusPaymentReq _$PaymentGetStatusPaymentReqFromJson(
        Map<String, dynamic> json) =>
    PaymentGetStatusPaymentReq(
      idPayment: json['id_payment'] as String?,
      period: json['period'] as String?,
    );

Map<String, dynamic> _$PaymentGetStatusPaymentReqToJson(
        PaymentGetStatusPaymentReq instance) =>
    <String, dynamic>{
      'id_payment': instance.idPayment,
      'period': instance.period,
    };
