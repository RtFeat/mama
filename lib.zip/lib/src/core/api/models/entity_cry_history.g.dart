// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'entity_cry_history.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

EntityCryHistory _$EntityCryHistoryFromJson(Map<String, dynamic> json) =>
    EntityCryHistory(
      notes: json['notes'] as String?,
      timeAll: json['time_all'] as String?,
      timeEnd: json['time_end'] as String?,
      timeStart: json['time_start'] as String?,
    );

Map<String, dynamic> _$EntityCryHistoryToJson(EntityCryHistory instance) =>
    <String, dynamic>{
      'notes': instance.notes,
      'time_all': instance.timeAll,
      'time_end': instance.timeEnd,
      'time_start': instance.timeStart,
    };
