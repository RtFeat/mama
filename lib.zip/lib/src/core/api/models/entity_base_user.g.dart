// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'entity_base_user.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

EntityBaseUser _$EntityBaseUserFromJson(Map<String, dynamic> json) =>
    EntityBaseUser(
      accountId: json['account_id'] as String?,
      city: json['city'] as String?,
      createdId: json['created_id'] as String?,
      endPrime: json['end_prime'] as String?,
      id: json['id'] as String?,
      roles:
          (json['roles'] as List<dynamic>?)?.map((e) => e as String).toList(),
      startPrime: json['start_prime'] as String?,
      typePrime: json['type_prime'] as String?,
      updatedId: json['updated_id'] as String?,
    );

Map<String, dynamic> _$EntityBaseUserToJson(EntityBaseUser instance) =>
    <String, dynamic>{
      'account_id': instance.accountId,
      'city': instance.city,
      'created_id': instance.createdId,
      'end_prime': instance.endPrime,
      'id': instance.id,
      'roles': instance.roles,
      'start_prime': instance.startPrime,
      'type_prime': instance.typePrime,
      'updated_id': instance.updatedId,
    };
