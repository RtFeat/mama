// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'entity_food_history.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

EntityFoodHistory _$EntityFoodHistoryFromJson(Map<String, dynamic> json) =>
    EntityFoodHistory(
      chest: (json['chest'] as num?)?.toInt(),
      mixture: (json['mixture'] as num?)?.toInt(),
      notes: json['notes'] as String?,
      time: json['time'] as String?,
      total: (json['total'] as num?)?.toInt(),
    );

Map<String, dynamic> _$EntityFoodHistoryToJson(EntityFoodHistory instance) =>
    <String, dynamic>{
      'chest': instance.chest,
      'mixture': instance.mixture,
      'notes': instance.notes,
      'time': instance.time,
      'total': instance.total,
    };
