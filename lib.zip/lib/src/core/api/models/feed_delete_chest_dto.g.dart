// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'feed_delete_chest_dto.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

FeedDeleteChestDto _$FeedDeleteChestDtoFromJson(Map<String, dynamic> json) =>
    FeedDeleteChestDto(
      id: json['id'] as String,
    );

Map<String, dynamic> _$FeedDeleteChestDtoToJson(FeedDeleteChestDto instance) =>
    <String, dynamic>{
      'id': instance.id,
    };
