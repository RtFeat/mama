// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'entity_child.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

EntityChild _$EntityChildFromJson(Map<String, dynamic> json) => EntityChild(
      avatar: json['avatar'] as String?,
      birthDate: json['birth_date'] as String?,
      childbirth: json['childbirth'] == null
          ? null
          : EntityChildbirth.fromJson(json['childbirth'] as String),
      childbirthWithComplications:
          json['childbirth_with_complications'] as bool?,
      createdAt: json['created_at'] as String?,
      firstName: json['first_name'] as String?,
      gender: json['gender'] as String?,
      headCirc: json['head_circ'] as num?,
      height: json['height'] as num?,
      id: json['id'] as String?,
      info: json['info'] as String?,
      isTwins: json['is_twins'] as bool?,
      secondName: json['second_name'] as String?,
      status: json['status'] == null
          ? null
          : EntityStatusOfChild.fromJson(
              json['status'] as Map<String, dynamic>),
      updatedAt: json['updated_at'] as String?,
      weight: json['weight'] as num?,
    );

Map<String, dynamic> _$EntityChildToJson(EntityChild instance) =>
    <String, dynamic>{
      'avatar': instance.avatar,
      'birth_date': instance.birthDate,
      'childbirth': _$EntityChildbirthEnumMap[instance.childbirth],
      'childbirth_with_complications': instance.childbirthWithComplications,
      'created_at': instance.createdAt,
      'first_name': instance.firstName,
      'gender': instance.gender,
      'head_circ': instance.headCirc,
      'height': instance.height,
      'id': instance.id,
      'info': instance.info,
      'is_twins': instance.isTwins,
      'second_name': instance.secondName,
      'status': instance.status,
      'updated_at': instance.updatedAt,
      'weight': instance.weight,
    };

const _$EntityChildbirthEnumMap = {
  EntityChildbirth.natural: 'NATURAL',
  EntityChildbirth.caesarean: 'CAESAREAN',
  EntityChildbirth.$unknown: r'$unknown',
};
