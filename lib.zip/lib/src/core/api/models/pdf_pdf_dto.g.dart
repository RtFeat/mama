// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'pdf_pdf_dto.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

PdfPdfDto _$PdfPdfDtoFromJson(Map<String, dynamic> json) => PdfPdfDto(
      childId: json['child_id'] as String?,
      typeOfPdf: json['type_of_pdf'] as String?,
    );

Map<String, dynamic> _$PdfPdfDtoToJson(PdfPdfDto instance) => <String, dynamic>{
      'child_id': instance.childId,
      'type_of_pdf': instance.typeOfPdf,
    };
