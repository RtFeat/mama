// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'entity_online_school_course.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

EntityOnlineSchoolCourse _$EntityOnlineSchoolCourseFromJson(
        Map<String, dynamic> json) =>
    EntityOnlineSchoolCourse(
      createdAt: json['created_at'] as String?,
      id: json['id'] as String?,
      link: json['link'] as String?,
      onlineSchoolId: json['online_school_id'] as String?,
      shortDescription: json['short_description'] as String?,
      title: json['title'] as String?,
    );

Map<String, dynamic> _$EntityOnlineSchoolCourseToJson(
        EntityOnlineSchoolCourse instance) =>
    <String, dynamic>{
      'created_at': instance.createdAt,
      'id': instance.id,
      'link': instance.link,
      'online_school_id': instance.onlineSchoolId,
      'short_description': instance.shortDescription,
      'title': instance.title,
    };
