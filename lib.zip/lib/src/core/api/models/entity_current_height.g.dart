// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'entity_current_height.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

EntityCurrentHeight _$EntityCurrentHeightFromJson(Map<String, dynamic> json) =>
    EntityCurrentHeight(
      data: json['data'] as String?,
      days: json['days'] as String?,
      height: json['height'] as String?,
      normal: json['normal'] as String?,
    );

Map<String, dynamic> _$EntityCurrentHeightToJson(
        EntityCurrentHeight instance) =>
    <String, dynamic>{
      'data': instance.data,
      'days': instance.days,
      'height': instance.height,
      'normal': instance.normal,
    };
