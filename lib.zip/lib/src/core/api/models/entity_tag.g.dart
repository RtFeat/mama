// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'entity_tag.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

EntityTag _$EntityTagFromJson(Map<String, dynamic> json) => EntityTag(
      id: json['id'] as String?,
      name: json['name'] as String?,
    );

Map<String, dynamic> _$EntityTagToJson(EntityTag instance) => <String, dynamic>{
      'id': instance.id,
      'name': instance.name,
    };
