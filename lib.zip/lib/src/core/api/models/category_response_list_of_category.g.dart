// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'category_response_list_of_category.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

CategoryResponseListOfCategory _$CategoryResponseListOfCategoryFromJson(
        Map<String, dynamic> json) =>
    CategoryResponseListOfCategory(
      list: (json['list'] as List<dynamic>?)
          ?.map(
              (e) => EntityCategoryQuantity.fromJson(e as Map<String, dynamic>))
          .toList(),
    );

Map<String, dynamic> _$CategoryResponseListOfCategoryToJson(
        CategoryResponseListOfCategory instance) =>
    <String, dynamic>{
      'list': instance.list,
    };
