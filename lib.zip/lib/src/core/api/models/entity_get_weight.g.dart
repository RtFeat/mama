// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'entity_get_weight.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

EntityGetWeight _$EntityGetWeightFromJson(Map<String, dynamic> json) =>
    EntityGetWeight(
      getWeights: json['get_weights'] as String?,
      isNormal: json['is_normal'] as String?,
      median: json['median'] as String?,
      normal: json['normal'] as String?,
      notes: json['notes'] as String?,
      weeks: json['weeks'] as String?,
      weight: json['weight'] as String?,
    );

Map<String, dynamic> _$EntityGetWeightToJson(EntityGetWeight instance) =>
    <String, dynamic>{
      'get_weights': instance.getWeights,
      'is_normal': instance.isNormal,
      'median': instance.median,
      'normal': instance.normal,
      'notes': instance.notes,
      'weeks': instance.weeks,
      'weight': instance.weight,
    };
