// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'entity_circle.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

EntityCircle _$EntityCircleFromJson(Map<String, dynamic> json) => EntityCircle(
      childId: json['child_id'] as String?,
      circle: json['circle'] as String?,
      createdAt: json['created_at'] as String?,
      id: json['id'] as String?,
      notes: json['notes'] as String?,
    );

Map<String, dynamic> _$EntityCircleToJson(EntityCircle instance) =>
    <String, dynamic>{
      'child_id': instance.childId,
      'circle': instance.circle,
      'created_at': instance.createdAt,
      'id': instance.id,
      'notes': instance.notes,
    };
