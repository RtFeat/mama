// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'payment_get_status_payment_resp.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

PaymentGetStatusPaymentResp _$PaymentGetStatusPaymentRespFromJson(
        Map<String, dynamic> json) =>
    PaymentGetStatusPaymentResp(
      status: json['status'] as String?,
    );

Map<String, dynamic> _$PaymentGetStatusPaymentRespToJson(
        PaymentGetStatusPaymentResp instance) =>
    <String, dynamic>{
      'status': instance.status,
    };
