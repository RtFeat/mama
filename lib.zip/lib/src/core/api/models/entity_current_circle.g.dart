// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'entity_current_circle.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

EntityCurrentCircle _$EntityCurrentCircleFromJson(Map<String, dynamic> json) =>
    EntityCurrentCircle(
      circle: json['circle'] as String?,
      data: json['data'] as String?,
      days: json['days'] as String?,
      normal: json['normal'] as String?,
    );

Map<String, dynamic> _$EntityCurrentCircleToJson(
        EntityCurrentCircle instance) =>
    <String, dynamic>{
      'circle': instance.circle,
      'data': instance.data,
      'days': instance.days,
      'normal': instance.normal,
    };
