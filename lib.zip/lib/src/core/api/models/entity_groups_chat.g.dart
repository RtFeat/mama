// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'entity_groups_chat.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

EntityGroupsChat _$EntityGroupsChatFromJson(Map<String, dynamic> json) =>
    EntityGroupsChat(
      avatar: json['avatar'] as String?,
      groupChat: json['group_chat'] as String?,
      id: json['id'] as String?,
      name: json['name'] as String?,
      numberOfOnlineUsers: (json['number_of_online_users'] as num?)?.toInt(),
      numberOfSpecialists: (json['number_of_specialists'] as num?)?.toInt(),
      numberOfUsers: (json['number_of_users'] as num?)?.toInt(),
    );

Map<String, dynamic> _$EntityGroupsChatToJson(EntityGroupsChat instance) =>
    <String, dynamic>{
      'avatar': instance.avatar,
      'group_chat': instance.groupChat,
      'id': instance.id,
      'name': instance.name,
      'number_of_online_users': instance.numberOfOnlineUsers,
      'number_of_specialists': instance.numberOfSpecialists,
      'number_of_users': instance.numberOfUsers,
    };
