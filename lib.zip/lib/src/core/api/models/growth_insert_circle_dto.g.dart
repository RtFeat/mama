// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'growth_insert_circle_dto.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

GrowthInsertCircleDto _$GrowthInsertCircleDtoFromJson(
        Map<String, dynamic> json) =>
    GrowthInsertCircleDto(
      childId: json['child_id'] as String?,
      circle: json['circle'] as String?,
      createdAt: json['created_at'] as String?,
      notes: json['notes'] as String?,
    );

Map<String, dynamic> _$GrowthInsertCircleDtoToJson(
        GrowthInsertCircleDto instance) =>
    <String, dynamic>{
      'child_id': instance.childId,
      'circle': instance.circle,
      'created_at': instance.createdAt,
      'notes': instance.notes,
    };
