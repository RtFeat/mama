// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'chat_get_chat_with_user_dto.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

ChatGetChatWithUserDto _$ChatGetChatWithUserDtoFromJson(
        Map<String, dynamic> json) =>
    ChatGetChatWithUserDto(
      accountId: json['account_id'] as String?,
    );

Map<String, dynamic> _$ChatGetChatWithUserDtoToJson(
        ChatGetChatWithUserDto instance) =>
    <String, dynamic>{
      'account_id': instance.accountId,
    };
