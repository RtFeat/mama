// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'chat_group_chats_response.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

ChatGroupChatsResponse _$ChatGroupChatsResponseFromJson(
        Map<String, dynamic> json) =>
    ChatGroupChatsResponse(
      chats: (json['chats'] as List<dynamic>?)
          ?.map((e) => EntityGroupChat.fromJson(e as Map<String, dynamic>))
          .toList(),
    );

Map<String, dynamic> _$ChatGroupChatsResponseToJson(
        ChatGroupChatsResponse instance) =>
    <String, dynamic>{
      'chats': instance.chats,
    };
