// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'entity_lure_history.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

EntityLureHistory _$EntityLureHistoryFromJson(Map<String, dynamic> json) =>
    EntityLureHistory(
      id: json['id'] as String?,
      gram: (json['gram'] as num?)?.toInt(),
      nameProduct: json['name_product'] as String?,
      notes: json['notes'] as String?,
      reaction: json['reaction'] as String?,
      time: json['time'] as String?,
    );

Map<String, dynamic> _$EntityLureHistoryToJson(EntityLureHistory instance) =>
    <String, dynamic>{
      'id': instance.id,
      'gram': instance.gram,
      'name_product': instance.nameProduct,
      'notes': instance.notes,
      'reaction': instance.reaction,
      'time': instance.time,
    };
