// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'entity_pumping_history.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

EntityPumpingHistory _$EntityPumpingHistoryFromJson(
        Map<String, dynamic> json) =>
    EntityPumpingHistory(
      id: json['id'] as String?,
      left: (json['left'] as num?)?.toInt(),
      notes: json['notes'] as String?,
      right: (json['right'] as num?)?.toInt(),
      time: json['time'] as String?,
      total: (json['total'] as num?)?.toInt(),
    );

Map<String, dynamic> _$EntityPumpingHistoryToJson(
        EntityPumpingHistory instance) =>
    <String, dynamic>{
      'id': instance.id,
      'left': instance.left,
      'notes': instance.notes,
      'right': instance.right,
      'time': instance.time,
      'total': instance.total,
    };
