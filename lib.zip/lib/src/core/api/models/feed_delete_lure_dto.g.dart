// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'feed_delete_lure_dto.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

FeedDeleteLureDto _$FeedDeleteLureDtoFromJson(Map<String, dynamic> json) =>
    FeedDeleteLureDto(
      id: json['id'] as String,
    );

Map<String, dynamic> _$FeedDeleteLureDtoToJson(FeedDeleteLureDto instance) =>
    <String, dynamic>{
      'id': instance.id,
    };
