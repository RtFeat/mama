// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'health_insert_temperature_dto.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

HealthInsertTemperatureDto _$HealthInsertTemperatureDtoFromJson(
        Map<String, dynamic> json) =>
    HealthInsertTemperatureDto(
      childId: json['child_id'] as String?,
      isBad: json['is_bad'] as bool?,
      notes: json['notes'] as String?,
      temperature: json['temperature'] as String?,
      time: json['time'] as String?,
    );

Map<String, dynamic> _$HealthInsertTemperatureDtoToJson(
        HealthInsertTemperatureDto instance) =>
    <String, dynamic>{
      'child_id': instance.childId,
      'is_bad': instance.isBad,
      'notes': instance.notes,
      'temperature': instance.temperature,
      'time': instance.time,
    };
