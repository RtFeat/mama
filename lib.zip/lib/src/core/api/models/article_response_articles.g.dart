// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'article_response_articles.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

ArticleResponseArticles _$ArticleResponseArticlesFromJson(
        Map<String, dynamic> json) =>
    ArticleResponseArticles(
      articles: (json['articles'] as List<dynamic>?)
          ?.map(
              (e) => EntityArticleResponse.fromJson(e as Map<String, dynamic>))
          .toList(),
    );

Map<String, dynamic> _$ArticleResponseArticlesToJson(
        ArticleResponseArticles instance) =>
    <String, dynamic>{
      'articles': instance.articles,
    };
