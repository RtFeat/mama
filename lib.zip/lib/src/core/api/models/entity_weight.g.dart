// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'entity_weight.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

EntityWeight _$EntityWeightFromJson(Map<String, dynamic> json) => EntityWeight(
      childId: json['child_id'] as String?,
      createdAt: json['created_at'] as String?,
      id: json['id'] as String?,
      notes: json['notes'] as String?,
      weight: json['weight'] as String?,
    );

Map<String, dynamic> _$EntityWeightToJson(EntityWeight instance) =>
    <String, dynamic>{
      'child_id': instance.childId,
      'created_at': instance.createdAt,
      'id': instance.id,
      'notes': instance.notes,
      'weight': instance.weight,
    };
