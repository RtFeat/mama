// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'chat_search_in_chat_resp.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

ChatSearchInChatResp _$ChatSearchInChatRespFromJson(
        Map<String, dynamic> json) =>
    ChatSearchInChatResp(
      message: (json['message'] as List<dynamic>?)
          ?.map((e) => EntityMessageResp.fromJson(e as Map<String, dynamic>))
          .toList(),
    );

Map<String, dynamic> _$ChatSearchInChatRespToJson(
        ChatSearchInChatResp instance) =>
    <String, dynamic>{
      'message': instance.message,
    };
