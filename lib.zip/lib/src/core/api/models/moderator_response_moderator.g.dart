// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'moderator_response_moderator.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

ModeratorResponseModerator _$ModeratorResponseModeratorFromJson(
        Map<String, dynamic> json) =>
    ModeratorResponseModerator(
      account: json['account'] == null
          ? null
          : EntityAccount.fromJson(json['account'] as Map<String, dynamic>),
    );

Map<String, dynamic> _$ModeratorResponseModeratorToJson(
        ModeratorResponseModerator instance) =>
    <String, dynamic>{
      'account': instance.account,
    };
