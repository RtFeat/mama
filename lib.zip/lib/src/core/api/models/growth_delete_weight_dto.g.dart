// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'growth_delete_weight_dto.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

GrowthDeleteWeightDto _$GrowthDeleteWeightDtoFromJson(
        Map<String, dynamic> json) =>
    GrowthDeleteWeightDto(
      id: json['id'] as String?,
    );

Map<String, dynamic> _$GrowthDeleteWeightDtoToJson(
        GrowthDeleteWeightDto instance) =>
    <String, dynamic>{
      'id': instance.id,
    };
