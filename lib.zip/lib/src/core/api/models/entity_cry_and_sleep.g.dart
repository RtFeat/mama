// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'entity_cry_and_sleep.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

EntityCryAndSleep _$EntityCryAndSleepFromJson(Map<String, dynamic> json) =>
    EntityCryAndSleep(
      cry: (json['cry'] as List<dynamic>?)
          ?.map((e) => EntityCry.fromJson(e as Map<String, dynamic>))
          .toList(),
      sleep: (json['sleep'] as List<dynamic>?)
          ?.map((e) => EntitySleep.fromJson(e as Map<String, dynamic>))
          .toList(),
    );

Map<String, dynamic> _$EntityCryAndSleepToJson(EntityCryAndSleep instance) =>
    <String, dynamic>{
      'cry': instance.cry,
      'sleep': instance.sleep,
    };
