// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'growth_response_insert.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

GrowthResponseInsert _$GrowthResponseInsertFromJson(
        Map<String, dynamic> json) =>
    GrowthResponseInsert(
      id: json['id'] as String?,
    );

Map<String, dynamic> _$GrowthResponseInsertToJson(
        GrowthResponseInsert instance) =>
    <String, dynamic>{
      'id': instance.id,
    };
