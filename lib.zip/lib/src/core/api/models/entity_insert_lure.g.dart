// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'entity_insert_lure.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

EntityInsertLure _$EntityInsertLureFromJson(Map<String, dynamic> json) =>
    EntityInsertLure(
      childId: json['child_id'] as String?,
      gram: (json['gram'] as num?)?.toInt(),
      nameProduct: json['name_product'] as String?,
      notes: json['notes'] as String?,
      reaction: json['reaction'] as String?,
      timeToEnd: json['time_to_end'] as String?,
    );

Map<String, dynamic> _$EntityInsertLureToJson(EntityInsertLure instance) =>
    <String, dynamic>{
      'child_id': instance.childId,
      'gram': instance.gram,
      'name_product': instance.nameProduct,
      'notes': instance.notes,
      'reaction': instance.reaction,
      'time_to_end': instance.timeToEnd,
    };
