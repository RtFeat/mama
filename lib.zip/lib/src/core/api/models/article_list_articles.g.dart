// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'article_list_articles.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

ArticleListArticles _$ArticleListArticlesFromJson(Map<String, dynamic> json) =>
    ArticleListArticles(
      articles: (json['articles'] as List<dynamic>?)
          ?.map((e) =>
              EntityListArticleResponse.fromJson(e as Map<String, dynamic>))
          .toList(),
    );

Map<String, dynamic> _$ArticleListArticlesToJson(
        ArticleListArticles instance) =>
    <String, dynamic>{
      'articles': instance.articles,
    };
