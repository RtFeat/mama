// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'entity_status_of_child.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

EntityStatusOfChild _$EntityStatusOfChildFromJson(Map<String, dynamic> json) =>
    EntityStatusOfChild(
      body: json['body'] as String?,
      description: json['description'] as String?,
      title: json['title'] as String?,
      value: json['value'] as String?,
    );

Map<String, dynamic> _$EntityStatusOfChildToJson(
        EntityStatusOfChild instance) =>
    <String, dynamic>{
      'body': instance.body,
      'description': instance.description,
      'title': instance.title,
      'value': instance.value,
    };
