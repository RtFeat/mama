// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'monday2.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

Monday2 _$Monday2FromJson(Map<String, dynamic> json) => Monday2(
      consultations: (json['consultations'] as List<dynamic>?)
          ?.map(
              (e) => EntityConsultationSlot.fromJson(e as Map<String, dynamic>))
          .toList(),
      workSlots: (json['work_slots'] as List<dynamic>?)
          ?.map((e) => EntityWorkSlot.fromJson(e as Map<String, dynamic>))
          .toList(),
    );

Map<String, dynamic> _$Monday2ToJson(Monday2 instance) => <String, dynamic>{
      'consultations': instance.consultations,
      'work_slots': instance.workSlots,
    };
