// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'feed_insert_chest_dto.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

FeedInsertChestDto _$FeedInsertChestDtoFromJson(Map<String, dynamic> json) =>
    FeedInsertChestDto(
      childId: json['child_id'] as String?,
      left: (json['left'] as num?)?.toInt(),
      notes: json['notes'] as String?,
      right: (json['right'] as num?)?.toInt(),
      timeToEnd: json['time_to_end'] as String?,
    );

Map<String, dynamic> _$FeedInsertChestDtoToJson(FeedInsertChestDto instance) =>
    <String, dynamic>{
      'child_id': instance.childId,
      'left': instance.left,
      'notes': instance.notes,
      'right': instance.right,
      'time_to_end': instance.timeToEnd,
    };
