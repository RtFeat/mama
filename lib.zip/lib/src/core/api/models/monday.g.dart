// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'monday.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

Monday _$MondayFromJson(Map<String, dynamic> json) => Monday(
      workSlots: (json['work_slots'] as List<dynamic>?)
          ?.map((e) => WorkSlots2.fromJson(e as Map<String, dynamic>))
          .toList(),
    );

Map<String, dynamic> _$MondayToJson(Monday instance) => <String, dynamic>{
      'work_slots': instance.workSlots,
    };
