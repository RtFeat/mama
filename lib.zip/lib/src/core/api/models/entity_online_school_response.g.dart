// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'entity_online_school_response.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

EntityOnlineSchoolResponse _$EntityOnlineSchoolResponseFromJson(
        Map<String, dynamic> json) =>
    EntityOnlineSchoolResponse(
      account: json['account'] == null
          ? null
          : EntityAccount.fromJson(json['account'] as Map<String, dynamic>),
      articleNumber: (json['article_number'] as num?)?.toInt(),
      articles: (json['articles'] as List<dynamic>?)
          ?.map(
              (e) => EntityArticleResponse.fromJson(e as Map<String, dynamic>))
          .toList(),
      course: json['course'] as bool?,
      createdAt: json['created_at'] as String?,
      id: json['id'] as String?,
      name: json['name'] as String?,
      updatedAt: json['updated_at'] as String?,
    );

Map<String, dynamic> _$EntityOnlineSchoolResponseToJson(
        EntityOnlineSchoolResponse instance) =>
    <String, dynamic>{
      'account': instance.account,
      'article_number': instance.articleNumber,
      'articles': instance.articles,
      'course': instance.course,
      'created_at': instance.createdAt,
      'id': instance.id,
      'name': instance.name,
      'updated_at': instance.updatedAt,
    };
