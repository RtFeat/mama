// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'entity_watcher.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

EntityWatcher _$EntityWatcherFromJson(Map<String, dynamic> json) =>
    EntityWatcher(
      accountId: json['account_id'] as String?,
      bottle: json['bottle'] as bool?,
      chest: json['chest'] as bool?,
      circle: json['circle'] as bool?,
      cry: json['cry'] as bool?,
      doctor: json['doctor'] as bool?,
      drug: json['drug'] as bool?,
      height: json['height'] as bool?,
      id: json['id'] as String?,
      lure: json['lure'] as bool?,
      pumping: json['pumping'] as bool?,
      sleep: json['sleep'] as bool?,
      temperature: json['temperature'] as bool?,
      vaccinations: json['vaccinations'] as bool?,
      weight: json['weight'] as bool?,
    );

Map<String, dynamic> _$EntityWatcherToJson(EntityWatcher instance) =>
    <String, dynamic>{
      'account_id': instance.accountId,
      'bottle': instance.bottle,
      'chest': instance.chest,
      'circle': instance.circle,
      'cry': instance.cry,
      'doctor': instance.doctor,
      'drug': instance.drug,
      'height': instance.height,
      'id': instance.id,
      'lure': instance.lure,
      'pumping': instance.pumping,
      'sleep': instance.sleep,
      'temperature': instance.temperature,
      'vaccinations': instance.vaccinations,
      'weight': instance.weight,
    };
