// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'child_status_response.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

ChildStatusResponse _$ChildStatusResponseFromJson(Map<String, dynamic> json) =>
    ChildStatusResponse(
      status:
          EntityStatusOfChild.fromJson(json['status'] as Map<String, dynamic>),
    );

Map<String, dynamic> _$ChildStatusResponseToJson(
        ChildStatusResponse instance) =>
    <String, dynamic>{
      'status': instance.status,
    };
