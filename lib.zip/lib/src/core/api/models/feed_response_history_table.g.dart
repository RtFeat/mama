// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'feed_response_history_table.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

FeedResponseHistoryTable _$FeedResponseHistoryTableFromJson(
        Map<String, dynamic> json) =>
    FeedResponseHistoryTable(
      list: (json['list'] as List<dynamic>?)
          ?.map((e) => EntityTableFeedTotal.fromJson(e as Map<String, dynamic>))
          .toList(),
    );

Map<String, dynamic> _$FeedResponseHistoryTableToJson(
        FeedResponseHistoryTable instance) =>
    <String, dynamic>{
      'list': instance.list,
    };
