// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'chat_all_chats_response.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

ChatAllChatsResponse _$ChatAllChatsResponseFromJson(
        Map<String, dynamic> json) =>
    ChatAllChatsResponse(
      chats: (json['chats'] as List<dynamic>?)
          ?.map((e) => EntitySingleChat.fromJson(e as Map<String, dynamic>))
          .toList(),
      groupChat: (json['group_chat'] as List<dynamic>?)
          ?.map((e) => EntityGroupChat.fromJson(e as Map<String, dynamic>))
          .toList(),
    );

Map<String, dynamic> _$ChatAllChatsResponseToJson(
        ChatAllChatsResponse instance) =>
    <String, dynamic>{
      'chats': instance.chats,
      'group_chat': instance.groupChat,
    };
