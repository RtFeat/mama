// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'entity_city.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

EntityCity _$EntityCityFromJson(Map<String, dynamic> json) => EntityCity(
      countryId: (json['country_id'] as num?)?.toInt(),
      countryName: json['country_name'] as String?,
      id: (json['id'] as num?)?.toInt(),
      name: json['name'] as String?,
    );

Map<String, dynamic> _$EntityCityToJson(EntityCity instance) =>
    <String, dynamic>{
      'country_id': instance.countryId,
      'country_name': instance.countryName,
      'id': instance.id,
      'name': instance.name,
    };
