// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'entity_sleep_history_total.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

EntitySleepHistoryTotal _$EntitySleepHistoryTotalFromJson(
        Map<String, dynamic> json) =>
    EntitySleepHistoryTotal(
      months: json['months'] as String?,
      sleepTotal: (json['sleep_total'] as List<dynamic>?)
          ?.map((e) => EntitySleepHistory.fromJson(e as Map<String, dynamic>))
          .toList(),
      time: json['time'] as String?,
      timeToEndTotal: json['time_to_end_total'] as String?,
    );

Map<String, dynamic> _$EntitySleepHistoryTotalToJson(
        EntitySleepHistoryTotal instance) =>
    <String, dynamic>{
      'months': instance.months,
      'sleep_total': instance.sleepTotal,
      'time': instance.time,
      'time_to_end_total': instance.timeToEndTotal,
    };
