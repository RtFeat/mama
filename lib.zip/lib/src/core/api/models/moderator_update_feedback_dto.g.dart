// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'moderator_update_feedback_dto.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

ModeratorUpdateFeedbackDto _$ModeratorUpdateFeedbackDtoFromJson(
        Map<String, dynamic> json) =>
    ModeratorUpdateFeedbackDto(
      id: json['id'] as String?,
      status: json['status'] as String?,
    );

Map<String, dynamic> _$ModeratorUpdateFeedbackDtoToJson(
        ModeratorUpdateFeedbackDto instance) =>
    <String, dynamic>{
      'id': instance.id,
      'status': instance.status,
    };
