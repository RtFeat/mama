// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'saturday2.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

Saturday2 _$Saturday2FromJson(Map<String, dynamic> json) => Saturday2(
      consultations: (json['consultations'] as List<dynamic>?)
          ?.map(
              (e) => EntityConsultationSlot.fromJson(e as Map<String, dynamic>))
          .toList(),
      workSlots: (json['work_slots'] as List<dynamic>?)
          ?.map((e) => EntityWorkSlot.fromJson(e as Map<String, dynamic>))
          .toList(),
    );

Map<String, dynamic> _$Saturday2ToJson(Saturday2 instance) => <String, dynamic>{
      'consultations': instance.consultations,
      'work_slots': instance.workSlots,
    };
