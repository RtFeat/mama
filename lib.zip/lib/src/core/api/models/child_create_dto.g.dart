// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'child_create_dto.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

ChildCreateDto _$ChildCreateDtoFromJson(Map<String, dynamic> json) =>
    ChildCreateDto(
      birthDate: json['birth_date'] as String,
      firstName: json['first_name'] as String,
      headCirc: json['head_circ'] as num,
      height: json['height'] as num,
      weight: json['weight'] as num,
      childbirth: json['childbirth'] as String?,
      childbirthWithComplications:
          json['childbirth_with_complications'] as bool?,
      gender: json['gender'] as String?,
      info: json['info'] as String?,
      isTwins: json['is_twins'] as bool?,
      secondName: json['second_name'] as String?,
    );

Map<String, dynamic> _$ChildCreateDtoToJson(ChildCreateDto instance) =>
    <String, dynamic>{
      'birth_date': instance.birthDate,
      'childbirth': instance.childbirth,
      'childbirth_with_complications': instance.childbirthWithComplications,
      'first_name': instance.firstName,
      'gender': instance.gender,
      'head_circ': instance.headCirc,
      'height': instance.height,
      'info': instance.info,
      'is_twins': instance.isTwins,
      'second_name': instance.secondName,
      'weight': instance.weight,
    };
