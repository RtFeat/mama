// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'growth_change_notes_height_dto.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

GrowthChangeNotesHeightDto _$GrowthChangeNotesHeightDtoFromJson(
        Map<String, dynamic> json) =>
    GrowthChangeNotesHeightDto(
      id: json['id'] as String?,
      notes: json['notes'] as String?,
    );

Map<String, dynamic> _$GrowthChangeNotesHeightDtoToJson(
        GrowthChangeNotesHeightDto instance) =>
    <String, dynamic>{
      'id': instance.id,
      'notes': instance.notes,
    };
