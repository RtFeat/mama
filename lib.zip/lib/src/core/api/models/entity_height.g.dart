// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'entity_height.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

EntityHeight _$EntityHeightFromJson(Map<String, dynamic> json) => EntityHeight(
      childId: json['child_id'] as String?,
      createdAt: json['created_at'] as String?,
      height: json['height'] as String?,
      id: json['id'] as String?,
      notes: json['notes'] as String?,
    );

Map<String, dynamic> _$EntityHeightToJson(EntityHeight instance) =>
    <String, dynamic>{
      'child_id': instance.childId,
      'created_at': instance.createdAt,
      'height': instance.height,
      'id': instance.id,
      'notes': instance.notes,
    };
