// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'entity_article_response.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

EntityArticleResponse _$EntityArticleResponseFromJson(
        Map<String, dynamic> json) =>
    EntityArticleResponse(
      account: json['account'] == null
          ? null
          : EntityAccount.fromJson(json['account'] as Map<String, dynamic>),
      ageCategory: (json['age_category'] as List<dynamic>?)
          ?.map((e) => e as String)
          .toList(),
      body: (json['body'] as List<dynamic>?)
          ?.map((e) => EntityBodyResponse.fromJson(e as Map<String, dynamic>))
          .toList(),
      category: json['category'] as String?,
      countArticlesAuthor: (json['count_articles_author'] as num?)?.toInt(),
      createdAt: json['created_at'] as String?,
      file: json['file'] as String?,
      id: json['id'] as String?,
      isFavorite: json['is_favorite'] as bool?,
      photoId: json['photo_id'] as String?,
      photoUrl: json['photo_url'] as String?,
      status: json['status'] as String?,
      subAccountDoctor: json['sub_account_doctor'] == null
          ? null
          : EntityDoctorBase.fromJson(
              json['sub_account_doctor'] as Map<String, dynamic>),
      subAccountOnlineSchool: json['sub_account_online_school'] == null
          ? null
          : EntityOnlineSchool.fromJson(
              json['sub_account_online_school'] as Map<String, dynamic>),
      tags: (json['tags'] as List<dynamic>?)?.map((e) => e as String).toList(),
      title: json['title'] as String?,
    );

Map<String, dynamic> _$EntityArticleResponseToJson(
        EntityArticleResponse instance) =>
    <String, dynamic>{
      'account': instance.account,
      'age_category': instance.ageCategory,
      'body': instance.body,
      'category': instance.category,
      'count_articles_author': instance.countArticlesAuthor,
      'created_at': instance.createdAt,
      'file': instance.file,
      'id': instance.id,
      'is_favorite': instance.isFavorite,
      'photo_id': instance.photoId,
      'photo_url': instance.photoUrl,
      'status': instance.status,
      'sub_account_doctor': instance.subAccountDoctor,
      'sub_account_online_school': instance.subAccountOnlineSchool,
      'tags': instance.tags,
      'title': instance.title,
    };
