// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'category_response_list_of_age_category.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

CategoryResponseListOfAgeCategory _$CategoryResponseListOfAgeCategoryFromJson(
        Map<String, dynamic> json) =>
    CategoryResponseListOfAgeCategory(
      list: (json['list'] as List<dynamic>?)
          ?.map((e) =>
              EntityAgeCategoryQuantity.fromJson(e as Map<String, dynamic>))
          .toList(),
    );

Map<String, dynamic> _$CategoryResponseListOfAgeCategoryToJson(
        CategoryResponseListOfAgeCategory instance) =>
    <String, dynamic>{
      'list': instance.list,
    };
