// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'entity_body_response.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

EntityBodyResponse _$EntityBodyResponseFromJson(Map<String, dynamic> json) =>
    EntityBodyResponse(
      payload: json['payload'],
      type: json['type'] as String?,
    );

Map<String, dynamic> _$EntityBodyResponseToJson(EntityBodyResponse instance) =>
    <String, dynamic>{
      'payload': instance.payload,
      'type': instance.type,
    };
