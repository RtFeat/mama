// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'growth_get_circle_response.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

GrowthGetCircleResponse _$GrowthGetCircleResponseFromJson(
        Map<String, dynamic> json) =>
    GrowthGetCircleResponse(
      list: json['list'] == null
          ? null
          : EntityTableCircle.fromJson(json['list'] as Map<String, dynamic>),
    );

Map<String, dynamic> _$GrowthGetCircleResponseToJson(
        GrowthGetCircleResponse instance) =>
    <String, dynamic>{
      'list': instance.list,
    };
