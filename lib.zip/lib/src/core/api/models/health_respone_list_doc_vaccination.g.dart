// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'health_respone_list_doc_vaccination.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

HealthResponeListDocVaccination _$HealthResponeListDocVaccinationFromJson(
        Map<String, dynamic> json) =>
    HealthResponeListDocVaccination(
      list: (json['list'] as List<dynamic>?)
          ?.map((e) =>
              HealthResponseDocVaccination.fromJson(e as Map<String, dynamic>))
          .toList(),
    );

Map<String, dynamic> _$HealthResponeListDocVaccinationToJson(
        HealthResponeListDocVaccination instance) =>
    <String, dynamic>{
      'list': instance.list,
    };
