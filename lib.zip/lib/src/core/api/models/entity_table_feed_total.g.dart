// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'entity_table_feed_total.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

EntityTableFeedTotal _$EntityTableFeedTotalFromJson(
        Map<String, dynamic> json) =>
    EntityTableFeedTotal(
      table: (json['table'] as List<dynamic>?)
          ?.map((e) => EntityTableFeed.fromJson(e as Map<String, dynamic>))
          .toList(),
      timeToEndTotal: json['time_to_end_total'] as String?,
    );

Map<String, dynamic> _$EntityTableFeedTotalToJson(
        EntityTableFeedTotal instance) =>
    <String, dynamic>{
      'table': instance.table,
      'time_to_end_total': instance.timeToEndTotal,
    };
