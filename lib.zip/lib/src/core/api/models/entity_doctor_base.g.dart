// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'entity_doctor_base.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

EntityDoctorBase _$EntityDoctorBaseFromJson(Map<String, dynamic> json) =>
    EntityDoctorBase(
      accountId: json['account_id'] as String?,
      createdAt: json['created_at'] as String?,
      id: json['id'] as String?,
      isConsultation: json['is_consultation'] as bool?,
      profession: json['profession'] as String?,
      updatedAt: json['updated_at'] as String?,
    );

Map<String, dynamic> _$EntityDoctorBaseToJson(EntityDoctorBase instance) =>
    <String, dynamic>{
      'account_id': instance.accountId,
      'created_at': instance.createdAt,
      'id': instance.id,
      'is_consultation': instance.isConsultation,
      'profession': instance.profession,
      'updated_at': instance.updatedAt,
    };
