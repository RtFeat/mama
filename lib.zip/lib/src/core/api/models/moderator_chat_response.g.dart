// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'moderator_chat_response.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

ModeratorChatResponse _$ModeratorChatResponseFromJson(
        Map<String, dynamic> json) =>
    ModeratorChatResponse(
      chat: json['chat'] == null
          ? null
          : EntitySingleChat.fromJson(json['chat'] as Map<String, dynamic>),
    );

Map<String, dynamic> _$ModeratorChatResponseToJson(
        ModeratorChatResponse instance) =>
    <String, dynamic>{
      'chat': instance.chat,
    };
