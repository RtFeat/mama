// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'moderator_create_dto.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

ModeratorCreateDto _$ModeratorCreateDtoFromJson(Map<String, dynamic> json) =>
    ModeratorCreateDto(
      email: json['email'] as String?,
      firstName: json['first_name'] as String?,
      lastName: json['last_name'] as String?,
      name: json['name'] as String?,
      phone: json['phone'] as String?,
      secondName: json['second_name'] as String?,
      specialization: json['specialization'] as String?,
      state: json['state'] == null
          ? null
          : EntityState.fromJson(json['state'] as String),
    );

Map<String, dynamic> _$ModeratorCreateDtoToJson(ModeratorCreateDto instance) =>
    <String, dynamic>{
      'email': instance.email,
      'first_name': instance.firstName,
      'last_name': instance.lastName,
      'name': instance.name,
      'phone': instance.phone,
      'second_name': instance.secondName,
      'specialization': instance.specialization,
      'state': _$EntityStateEnumMap[instance.state],
    };

const _$EntityStateEnumMap = {
  EntityState.active: 'ACTIVE',
  EntityState.inactive: 'INACTIVE',
  EntityState.deleted: 'DELETED',
  EntityState.blocked: 'BLOCKED',
  EntityState.unregistered: 'UNREGISTERED',
  EntityState.$unknown: r'$unknown',
};
