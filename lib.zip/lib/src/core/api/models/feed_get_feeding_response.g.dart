// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'feed_get_feeding_response.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

FeedGetFeedingResponse _$FeedGetFeedingResponseFromJson(
        Map<String, dynamic> json) =>
    FeedGetFeedingResponse(
      list: (json['list'] as List<dynamic>?)
          ?.map((e) => EntityFeeding.fromJson(e as Map<String, dynamic>))
          .toList(),
    );

Map<String, dynamic> _$FeedGetFeedingResponseToJson(
        FeedGetFeedingResponse instance) =>
    <String, dynamic>{
      'list': instance.list,
    };
