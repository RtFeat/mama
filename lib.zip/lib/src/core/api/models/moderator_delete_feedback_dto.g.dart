// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'moderator_delete_feedback_dto.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

ModeratorDeleteFeedbackDto _$ModeratorDeleteFeedbackDtoFromJson(
        Map<String, dynamic> json) =>
    ModeratorDeleteFeedbackDto(
      id: json['id'] as String?,
    );

Map<String, dynamic> _$ModeratorDeleteFeedbackDtoToJson(
        ModeratorDeleteFeedbackDto instance) =>
    <String, dynamic>{
      'id': instance.id,
    };
