// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'growth_insert_height_dto.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

GrowthInsertHeightDto _$GrowthInsertHeightDtoFromJson(
        Map<String, dynamic> json) =>
    GrowthInsertHeightDto(
      childId: json['child_id'] as String?,
      createdAt: json['created_at'] as String?,
      height: json['height'] as String?,
      notes: json['notes'] as String?,
    );

Map<String, dynamic> _$GrowthInsertHeightDtoToJson(
        GrowthInsertHeightDto instance) =>
    <String, dynamic>{
      'child_id': instance.childId,
      'created_at': instance.createdAt,
      'height': instance.height,
      'notes': instance.notes,
    };
