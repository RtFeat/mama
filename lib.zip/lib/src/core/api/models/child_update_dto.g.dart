// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'child_update_dto.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

ChildUpdateDto _$ChildUpdateDtoFromJson(Map<String, dynamic> json) =>
    ChildUpdateDto(
      birthDate: json['birth_date'] as String,
      id: json['id'] as String,
      childbirth: json['childbirth'] as String?,
      childbirthWithComplications:
          json['childbirth_with_complications'] as bool?,
      firstName: json['first_name'] as String?,
      gender: json['gender'] as String?,
      headCirc: json['head_circ'] as num?,
      height: json['height'] as num?,
      info: json['info'] as String?,
      isTwins: json['is_twins'] as bool?,
      secondName: json['second_name'] as String?,
      weight: json['weight'] as num?,
    );

Map<String, dynamic> _$ChildUpdateDtoToJson(ChildUpdateDto instance) =>
    <String, dynamic>{
      'birth_date': instance.birthDate,
      'childbirth': instance.childbirth,
      'childbirth_with_complications': instance.childbirthWithComplications,
      'first_name': instance.firstName,
      'gender': instance.gender,
      'head_circ': instance.headCirc,
      'height': instance.height,
      'id': instance.id,
      'info': instance.info,
      'is_twins': instance.isTwins,
      'second_name': instance.secondName,
      'weight': instance.weight,
    };
