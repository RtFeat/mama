// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'doctor_update_work_time.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

DoctorUpdateWorkTime _$DoctorUpdateWorkTimeFromJson(
        Map<String, dynamic> json) =>
    DoctorUpdateWorkTime(
      friday: json['friday'] == null
          ? null
          : Friday.fromJson(json['friday'] as Map<String, dynamic>),
      monday: json['monday'] == null
          ? null
          : Monday.fromJson(json['monday'] as Map<String, dynamic>),
      saturday: json['saturday'] == null
          ? null
          : Saturday.fromJson(json['saturday'] as Map<String, dynamic>),
      sunday: json['sunday'] == null
          ? null
          : Sunday.fromJson(json['sunday'] as Map<String, dynamic>),
      thursday: json['thursday'] == null
          ? null
          : Thursday.fromJson(json['thursday'] as Map<String, dynamic>),
      tuesday: json['tuesday'] == null
          ? null
          : Tuesday.fromJson(json['tuesday'] as Map<String, dynamic>),
      wednesday: json['wednesday'] == null
          ? null
          : Wednesday.fromJson(json['wednesday'] as Map<String, dynamic>),
      weekStart: json['week_start'] as String?,
    );

Map<String, dynamic> _$DoctorUpdateWorkTimeToJson(
        DoctorUpdateWorkTime instance) =>
    <String, dynamic>{
      'friday': instance.friday,
      'monday': instance.monday,
      'saturday': instance.saturday,
      'sunday': instance.sunday,
      'thursday': instance.thursday,
      'tuesday': instance.tuesday,
      'wednesday': instance.wednesday,
      'week_start': instance.weekStart,
    };
